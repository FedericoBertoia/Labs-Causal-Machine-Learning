# knitr::opts_chunk$set(echo    = TRUE,
#                       warning = FALSE,
#                       message = FALSE,
#                       error   = FALSE,
#                       comment = "",
#                       dev.args = list(png = list(type = "cairo")))

library(hdm)          # pension data
library(grf)          # causal forest
library(SuperLearner) 
library(ranger)       # SL.ranger
library(gam)          # SL.gam
library(earth)        # SL.earth (MARS)
library(tidyverse)
library(scales)
library(patchwork)    

# Setup ---------
set.seed(2)

out_dir <- getwd()

# Set a global theme / palette https://stackoverflow.com/questions/50741128/set-a-theme-and-palette-for-all-plots

cml_blue   <- "steelblue"   
cml_red    <- "tomato"   
cml_grey   <- "grey40"    
cml_fill   <- "#3B7BB7"   
cml_pal2   <- c(cml_blue, cml_red)                       
cml_pal3   <- c(cml_red, "#E89C3B", cml_blue)            

theme_cml <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      #panel.grid.minor = element_blank(),
      legend.position  = "top"
    )
}

theme_set(theme_cml())

# set defaults https://jofrhwld.github.io/blog/posts/2024/10/2024-10-01_ggplot2-default-colors/
options(
  ggplot2.discrete.colour = list(cml_pal2, cml_pal3),
  ggplot2.discrete.fill   = list(cml_pal2, cml_pal3)
)


# Data -----
data(pension)

# for ease of coding
Y    <- pension$net_tfa
A    <- pension$e401
X    <- as.matrix(pension[, c("age", "inc", "fsize", "educ",
                              "marr", "twoearn", "db", "pira", "hown")])
X_df <- as.data.frame(X)
N    <- nrow(X)


# little bit of IDA -----

cat("n =", N, " | Proportion eligible:", round(mean(A), 3), "\n")
summary(X_df)

# Library to use in each SuperLearner ------
SL.library <- c("SL.mean", "SL.glm", "SL.ranger", "SL.gam", "SL.earth")
cat("SuperLearner library:", paste(SL.library, collapse = ", "), "\n")


# Cross fitting of nuisance parameters ------

n_folds <- 5
fold_id <- sample(rep(1:n_folds, length.out = N))
folds   <- split(seq_len(N), fold_id)
cat(sprintf("Cross-fitting setup: K = %d folds\n", n_folds))

## Q1 Q0 hat : hatE(Y|AX) -----------
Q1_hat <- numeric(N)
Q0_hat <- numeric(N)
AX_df  <- data.frame(A = A, X_df)
  
  for (k in 1:n_folds) {
    test  <- folds[[k]]
    train <- setdiff(seq_len(N), test)
  
    sl_Q <- SuperLearner(
      Y          = Y[train],
      X          = AX_df[train, ],
      SL.library = SL.library,
      family     = gaussian(),
      method     = "method.NNLS",
      cvControl  = list(V = 5)
    )
  
    newdat_1 <- data.frame(A = rep(1L, length(test)), X_df[test, ])
    newdat_0 <- data.frame(A = rep(0L, length(test)), X_df[test, ])
  
    Q1_hat[test] <- predict(sl_Q, newdata = newdat_1)$pred
    Q0_hat[test] <- predict(sl_Q, newdata = newdat_0)$pred
   
}


cat("Q_hat(1, x) summary:\n"); print(summary(Q1_hat))
cat("\nQ_hat(0, x) summary:\n"); print(summary(Q0_hat))

## Y-hat: hatE(Y|X) ----------------------

Y_hat <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)

  sl_Y <- SuperLearner(
    Y          = Y[train],
    X          = X_df[train, ],
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS",
    cvControl  = list(V = 5)
  )


  Y_hat[test] <- predict(sl_Y, newdata = X_df[test, ])$pred

}  



cat("Y_hat summary:\n"); print(summary(Y_hat))


## pi-hat -----------

pi_hat <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)

  sl_pi <- SuperLearner(
    Y          = A[train],
    X          = X_df[train, ],
    SL.library = SL.library,
    family     = binomial(),
    method     = "method.NNLS",
    cvControl  = list(V = 5)
  )

  pi_hat[test] <- predict(sl_pi, newdata = X_df[test, ])$pred

}


## Truncation needed ? --> NO
# pi_hat <- pmin(pmax(pi_hat, 0.01), 0.99)
summary(pi_hat)


# overlap pi hat
p_ps_overlap <- tibble(p = pi_hat,
                       group = factor(A, levels = c(0, 1), labels = c("Ineligible (e401 = 0)", "Eligible   (e401 = 1)"))) %>% 
  ggplot(aes(x = p, fill = group)) +
  geom_histogram(bins = 60, alpha = 0.7, colour = NA) +
  geom_vline(xintercept = c(0.05, 0.95), linetype = "dashed",
             colour = cml_grey, linewidth = 0.4) +
  scale_fill_manual(values = cml_pal2) +
  labs(
       x = "Estimated propensity score", y = "Count", fill = NULL) +
  scale_x_continuous(breaks = (0:4)/4, labels = (0:4)/4) +
  coord_cartesian(xlim = c(0, 1))+
  theme(legend.position  = "top")

ggsave(file.path(out_dir, "plot_q1_propensity_overlap.png"),
       plot = p_ps_overlap, width = 8, height = 5, dpi = 150)
p_ps_overlap


# Check tails of ipscore distributions
ps_df <- tibble(e401 = A, pi_hat = pi_hat)

ps_extreme <- bind_rows(
  
  ps_df %>% group_by(e401) %>% slice_min(pi_hat, n = 10) %>%
    mutate(tail = "Lowest 10 propensities"),
  
  ps_df %>% group_by(e401) %>% slice_max(pi_hat, n = 10) %>%
    mutate(tail = "Highest 10 propensities")
  
) %>%
  mutate(tail = factor(tail, levels = c("Lowest 10 propensities",
                                        "Highest 10 propensities")),
         group = factor(e401, levels = c(0, 1),
                        labels = c("Ineligible", "Eligible")))

p_ps_extremes <- ggplot(ps_extreme, aes(group, pi_hat, colour = group)) +
  geom_point() +
  facet_wrap(~ tail, scales = "free_y") +
  scale_colour_manual(values = cml_pal2) +
  scale_y_continuous(labels = function(x) sprintf("%.3f", x)) +
  labs(
       x = NULL, y = expression(hat(pi)(x)), colour = NULL)+theme(legend.position  = "top")

ggsave(file.path(out_dir, "plot_q1_propensity_extremes.png"),
       plot = p_ps_extremes, width = 9, height = 5, dpi = 150)
p_ps_extremes


# Compute IP-weights
ipw        <- ifelse(A == 1, 1 / pi_hat, 1 / (1 - pi_hat))

# check for extreme weights
extreme_ps <- mean(pi_hat < 0.05 | pi_hat > 0.95)

cat(sprintf("Max IPW weight            : %.1f\n", max(ipw)),
    sprintf("99th-percentile IPW weight: %.1f\n", quantile(ipw, 0.99)),
    sprintf("P(pi_hat not in [0.05, 0.95]) : %.4f (%.2f%%)\n",
            extreme_ps, 100 * extreme_ps))


# Check covariate balance before vs after weighting
catvars <- c("marr", "twoearn", "db", "pira", "hown", "fsize", "educ")

bal_df <- pension %>% 
  select(e401, age, inc, fsize, educ, marr, twoearn, db, pira, hown) %>% 
  mutate(weight = ifelse(e401 == 1, 1 / pi_hat, 1 / (1 - pi_hat))) %>% 
  pivot_longer(-c(e401, weight), names_to = "variable") %>% 
  mutate(is_cat = variable %in% catvars)

p_bal_unw <- ggplot(bal_df,
                    aes(x = value, fill = factor(e401), colour = factor(e401))) +
  geom_bar(data = ~ filter(.x, is_cat),
           width = 0.4, position = "dodge", alpha = 0.6) +
  geom_density(data = ~ filter(.x, !is_cat), alpha = 0.3, linewidth = 0.8) +
  facet_wrap(~ variable, scales = "free") +
  scale_fill_manual(values = cml_pal2) +
  scale_colour_manual(values = cml_pal2) +
  labs(
       fill = "e401", colour = "e401",
       x = NULL, y = "Count / Density")

ggsave(file.path(out_dir, "plot_q1_balance_unweighted.png"),
       plot = p_bal_unw, width = 10, height = 7, dpi = 150)
p_bal_unw

p_bal_wtd <- ggplot(bal_df,
                    aes(x = value, fill = factor(e401), colour = factor(e401),
                        weight = weight)) +
  geom_bar(data = ~ filter(.x, is_cat),
           width = 0.4, position = "dodge", alpha = 0.6) +
  geom_density(data = ~ filter(.x, !is_cat), alpha = 0.3, linewidth = 0.8) +
  facet_wrap(~ variable, scales = "free") +
  scale_fill_manual(values = cml_pal2) +
  scale_colour_manual(values = cml_pal2) +
  labs(
       fill = "e401", colour = "e401",
       x = NULL, y = "Count / Density (weighted)")

ggsave(file.path(out_dir, "plot_q1_balance_weighted.png"),
       plot = p_bal_wtd, width = 10, height = 7, dpi = 150)
p_bal_wtd



# Causal forest fit (and out of bag predictions)
  
cf <- causal_forest(
  X               = X,
  Y               = Y,
  W               = A,
  Y.hat           = Y_hat,
  W.hat           = pi_hat,
  num.trees       = 2000,
  tune.parameters = "all",
  # seed            = 2  # seed is set globally
  )


# get out of bag predictions
cate_out <- predict(cf, estimate.variance = TRUE)
tau_hat  <- cate_out$predictions
tau_se   <- sqrt(cate_out$variance.estimates)
summary(tau_hat)


# eif for estimating ATE via AIPW  (to give some context to the CATEs)
psi <- (Q1_hat - Q0_hat) +
  A       / pi_hat       * (Y - Q1_hat) -
  (1 - A) / (1 - pi_hat) * (Y - Q0_hat)

ate_est <- mean(psi)
ate_se  <- sd(psi) / sqrt(N)
ate_lo  <- ate_est - 1.96 * ate_se
ate_hi  <- ate_est + 1.96 * ate_se

cat("Average Treatment Effect (AIPW, cross-fitted)\n",
    sprintf("  Estimate : $%7.1f\n", ate_est),
    sprintf("  Std.Err  : $%7.1f\n", ate_se),
    sprintf("  95%% CI  : [$%.1f,  $%.1f]\n", ate_lo, ate_hi))

psi_sd     <- sd(psi)
psi_mean   <- mean(psi)
extreme_if <- sum(abs(psi - psi_mean) > 5 * psi_sd)

summary(psi)
cat(sprintf("\nObservations with |psi_hat - mean| > 5 SD: %d (%.2f%%)\n",
            extreme_if, 100 * extreme_if / N))


# BLP ------------ Chernozhukov --------
tau_bar <- mean(tau_hat)
C_blp   <- tau_bar             * (A - pi_hat)
D_blp   <- (tau_hat - tau_bar) * (A - pi_hat)
Ytil    <- Y - Y_hat

blp_mod <- lm(Ytil ~ -1 + C_blp + D_blp)

library(lmtest)
coeftest(blp_mod, vcov. = \(m) sandwich::vcovHC(m, type = "HC3"))

coeftest(blp_mod, vcov. = \(m) sandwich::vcovHC(m, type = "HC3"))[, 4] /2

# check if we get same results
cal <- test_calibration(cf)
print(cal)


# cate histogram ------
p_cate_hist <- ggplot(tibble(tau = tau_hat), aes(x = tau)) +
  geom_histogram(bins = 60, fill = cml_blue, colour = "white", alpha = 0.9) +
  geom_vline(xintercept = ate_est, colour = cml_red,
             linewidth = 1, linetype = "dashed") +
  annotate("text",
           x = ate_est + diff(range(tau_hat)) * 0.03, y = Inf,
           label = sprintf("ATE = $%.0f", ate_est),
           colour = cml_red, vjust = 2, hjust = 0, size = 3.8) +
  labs(
       x = "Estimated treatment effect (USD)", y = "Count")

ggsave(file.path(out_dir, "plot_q1_cate_histogram.png"),
       plot = p_cate_hist, width = 8, height = 5, dpi = 150)
p_cate_hist


# cate vs income ----

p_cate_inc <- ggplot(
  data.frame(income = pension$inc / 1e3, tau = tau_hat),
  aes(x = income, y = tau)
) +
  geom_point(alpha = 0.10, size = 0.6, colour = cml_blue) +
  geom_smooth(method = "loess", span = 0.4, se = F,
              colour = cml_red, fill = cml_red,
              alpha = 0.20, linewidth = 1.1) +
  geom_hline(yintercept = ate_est, linetype = "dashed",
             colour = cml_grey, linewidth = 0.7) +
  annotate("text", x = Inf, y = ate_est,
           label = sprintf(" ATE = $%.0f", ate_est),
           colour = cml_grey, hjust = 1.05, vjust = -0.5, size = 3.5) +
  #
  #scale_y_continuous(labels = comma) +
  labs(
       x = "Household income (USD thousands)", y = "Estimated CATE (USD)")

ggsave(file.path(out_dir, "plot_q1_cate_vs_income.png"),
       plot = p_cate_inc, width = 8, height = 5, dpi = 150)
p_cate_inc


# cate vs all ----

p_cate_all <- AX_df %>%
  rename(e401 = A) %>%
  mutate(taui = predict(cf)$predictions) %>%
  pivot_longer(-c(taui)) %>%
  mutate(is_cat = name %in% c(catvars, "e401")) %>%
  ggplot(aes(x = value, y = taui)) +
  geom_hline(yintercept = ate_est, linetype = "dashed",
             colour = cml_grey, linewidth = 0.5) +
  geom_boxplot(aes(x = factor(value)), data = ~ filter(.x, is_cat),
               outlier.size = 0.1, fill = cml_blue, alpha = 0.4,
               colour = cml_blue) +
  geom_point(data = ~ filter(.x, !is_cat), pch = ".",
             colour = cml_blue, alpha = 0.3) +
  geom_smooth(data = ~ filter(.x, !is_cat), se = FALSE,
              colour = cml_red, linewidth = 1) +
  facet_wrap(~ name, scales = "free_x", ncol = 3) +
  labs(
       y = "Estimated CATE (USD)", x = NULL)

ggsave(file.path(out_dir, "plot_q1_cate_vs_all.png"),
       plot = p_cate_all, width = 10, height = 8, dpi = 150)
p_cate_all


# varimp ------

varimp <- variable_importance(cf)
vi_df  <- data.frame(variable   = colnames(X),
                     importance = as.numeric(varimp)) |>
  arrange(desc(importance))

print(vi_df)

p_vi <- ggplot(vi_df, aes(x = reorder(variable, importance), y = importance)) +
  geom_col(fill = cml_blue, alpha = 0.9, width = 0.65) +
  coord_flip() +
  labs(
       x = NULL, y = "Importance score")

ggsave(file.path(out_dir, "plot_q1_variable_importance.png"),
       plot = p_vi, width = 7, height = 5, dpi = 150)
p_vi

# extreme eifs---------
df_if <- tibble(
  eif   = psi - mean(psi),
  extreme = factor(
    abs(eif) > 5 * psi_sd,
    levels = c(FALSE, TRUE),
    labels = c("Normal", "Extreme (> 5 SD)")
  )
)

p_if <- ggplot(df_if, aes(x = eif, fill = extreme)) +
  geom_histogram(bins = 80, colour = "white") +
  scale_fill_manual(values = c("Normal" = cml_blue,
                               "Extreme (> 5 SD)" = cml_red)) +

  labs(
       x = "Influence function value (USD)", y = "Count", fill = NULL)

ggsave(file.path(out_dir, "plot_q1_influence_functions.png"),
       plot = p_if, width = 8, height = 5, dpi = 150)
p_if

p_if_zoom <- ggplot(df_if, aes(x = eif)) +
  geom_histogram(bins = 1000, fill = cml_blue, colour = "white") +
  geom_vline(xintercept = 0, linetype = "dotted", colour = cml_grey) +
  
  labs(
       x = "Influence function value (USD)", y = "Count") +
  coord_cartesian(xlim = c(-1, 1) * 1e5)

ggsave(file.path(out_dir, "plot_q1_influence_zoom.png"),
       plot = p_if_zoom, width = 8, height = 5, dpi = 150)
p_if_zoom


# parial dependence plots -------
# set.seed(2)
pe_idx <- sample(seq_len(N), 1000)
X_pe   <- X_df[pe_idx, ]

partial_effect <- function(varname, grid) {
  map(grid, \(v) {
    Xnew <- X_pe
    Xnew[[varname]] <- v
    tibble(val = v,
           tau = predict(cf, newdata = as.matrix(Xnew))$predictions,
           var = varname)
  }) %>% list_rbind()

}
pe_all <- X_df %>% 
  colnames() %>% 
  map2(list("age" = 25:64,
         "inc" = seq(min(pension$inc), max(pension$inc), by = 5000),
         "fsize" = 1:13,
         "educ" = 1:18,
         "marr" = 0:1,
         "twoearn" = 0:1,
         "db" = 0:1,
         "pira" = 0:1,
         "hown" = 0:1),
       partial_effect) %>% 
  list_rbind()




p_partials <- pe_all %>%
  mutate(is_cat = var %in% catvars) %>%
  ggplot(aes(x = val, y = tau)) +
  geom_hline(yintercept = ate_est, linetype = "dashed",
             colour = cml_grey, linewidth = 0.5) +
  stat_summary(aes(x = factor(val), group = 1),
               data = ~ filter(.x, is_cat), fun = mean,
               colour = cml_grey, linewidth = 0.5, geom = "line") +
  stat_summary(aes(x = factor(val)),
               data = ~ filter(.x, is_cat), fun = mean,
               colour = cml_red, size = 0.1) +
  geom_smooth(data = ~ filter(.x, !is_cat), se = FALSE,
              colour = cml_red, linewidth = 1) +
  facet_wrap(~ var, scales = "free") +
  #scale_y_continuous(labels = comma) +
  labs(
       x = NULL, y = "Predicted CATE (USD)")

ggsave(file.path(out_dir, "plot_q1_partial_effects.png"),
       plot = p_partials, width = 12, height = 8, dpi = 150)
p_partials


# Q2 ------------

## Method 1 ----------

subgroup <- ntile(tau_hat, 4)

results_q2 <-  map(1:4, \(g) {
  idx   <- subgroup == g
  psi_g <- psi[idx]
  n_g   <- length(psi_g)
  ate_g <- mean(psi_g)
  se_g  <- sd(psi_g) / sqrt(n_g)
  
  tibble(
    subgroup  = g,
    label     = paste0("Q", g),
    n         = n_g,
    ate       = ate_g,
    se        = se_g,
    ci_lo     = ate_g - 1.96 * se_g,
    ci_hi     = ate_g + 1.96 * se_g,
    tau_mean  = mean(tau_hat[idx]),
    tau_range = paste0(round(min(tau_hat[idx])),
                       " – ", round(max(tau_hat[idx])))
  )
}) %>% 
  list_rbind()

print(results_q2[, c("subgroup", "n", "ate", "se", "tau_range", "ci_lo", "ci_hi")],
      digits = 2, row.names = FALSE)

cat("Extreme influence functions per subgroup (|psi - mean| > 5 SD)\n")
for (g in 1:4) {
  idx   <- subgroup == g
  psi_g <- psi[idx]
  n_ext <- sum(abs(psi_g - mean(psi_g)) > 5 * sd(psi_g))
  cat(sprintf("  Q%d: %d extreme (%.2f%%)\n",
              g, n_ext, 100 * n_ext / sum(idx)))
}

# set.seed(2)

## Method 2 ----------------

tau_cross <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)

  cf_k <- causal_forest(
    X               = X[train, ],
    Y               = Y[train],
    W               = A[train],
    Y.hat           = Y_hat[train],  # cross-fitted
    W.hat           = pi_hat[train], # cross-fitted
    num.trees       = 2000,
    tune.parameters = "all",
    # seed            = 2
  )

  tau_cross[test] <- predict(cf_k, newdata = X[test, ])$predictions
}

subgroup_cf <- ntile(tau_cross, 4)

results_q2_cf2 <- map(1:4, \(g) {

  idx   <- subgroup_cf == g
  N_w <- sum(idx)
  n_folds_w <- 5
  fold_id_w <- sample(rep(1:n_folds_w, length.out = N_w))
  folds_w   <- split(seq_len(N_w), fold_id_w)
  
  # Q1/0 within bin
  Q1_hat_w <- numeric(N_w)
  Q0_hat_w <- numeric(N_w)
  AX_df_w  <- data.frame(A = A, X_df)[idx, ]
  
  for (k in 1:n_folds_w) {
    test  <- folds_w[[k]]
    train <- setdiff(seq_len(N_w), test)
  
    sl_Q_w <- SuperLearner(
      Y          = Y[idx][train],
      X          = AX_df_w[train, ],
      SL.library = SL.library,
      family     = gaussian(),
      method     = "method.NNLS",
      cvControl  = list(V = 5)
    )
  
    newdat_1_w <- data.frame(A = rep(1L, length(test)), X_df[idx, ][test, ])
    newdat_0_w <- data.frame(A = rep(0L, length(test)), X_df[idx, ][test, ])
  
    Q1_hat_w[test] <- predict(sl_Q_w, newdata = newdat_1_w)$pred
    Q0_hat_w[test] <- predict(sl_Q_w, newdata = newdat_0_w)$pred
  }
    # pi_hat within bin
   pi_hat_w <- numeric(N_w)
  
  for (k in 1:n_folds) {
    test  <- folds_w[[k]]
    train <- setdiff(seq_len(N_w), test)
  
    sl_pi_w <- SuperLearner(
      Y          = A[idx][train],
      X          = X_df[idx, ][train, ],
      SL.library = SL.library,
      family     = binomial(),
      method     = "method.NNLS",
      cvControl  = list(V = 5)
    )
  
    pi_hat_w[test] <- predict(sl_pi_w, newdata = X_df[idx, ][test, ])$pred
  }
  
  ## Truncate to keep IPW weights finite (positivity safeguard)
  pi_hat_w <- pmin(pmax(pi_hat_w, 0.01), 0.99)
  
  # ATE within bin
  
  psi_w <- (Q1_hat_w - Q0_hat_w) +
  A[idx]       / pi_hat_w       * (Y[idx] - Q1_hat_w) -
  (1 - A[idx]) / (1 - pi_hat_w) * (Y[idx] - Q0_hat_w)

  ate_g <- mean(psi_w)
  se_g  <- sd(psi_w) / sqrt(N_w)
  
  
  cat("Extreme influence functions per subgroup (|psi - mean| > 5 SD)\n")

    n_ext_w <- sum(abs(psi_w - mean(psi_w)) > 5 * sd(psi_w))
    cat(sprintf("  Q%d: %d extreme (%.2f%%)\n",
                g, n_ext_w, 100 * n_ext_w / sum(idx))) # idx is logical

  
  
  tibble(
    subgroup  = g,
    label     = paste0("Q", g),
    n         = N_w,
    ate       = ate_g,
    se        = se_g,
    ci_lo     = ate_g - 1.96 * se_g,
    ci_hi     = ate_g + 1.96 * se_g,
    tau_mean  = mean(tau_cross[idx]),
    tau_range = paste0(round(min(tau_cross[idx])),
                       " – ", round(max(tau_cross[idx])))
  )
}) %>% 
  list_rbind()

print(results_q2_cf2[, c("subgroup", "n", "ate", "se",
                        "tau_range", "ci_lo", "ci_hi")],
      digits = 2, row.names = FALSE)

## Naive --------------

naive <- tibble(tau_hat = tau_hat, 
                bin = ntile(tau_hat, 4)) %>%
  summarise(tau_mean = mean(tau_hat), 
            ate = tau_mean,
            se = sd(tau_hat)/sqrt(n()),
            n = n(),
            tau_range = paste(round(min(tau_hat)), "-", round(max(tau_hat))),
            .by = bin) %>% 
  mutate(ci_lo = tau_mean - 1.96*se,
         ci_hi = tau_mean + 1.96*se,
         label = paste0("Q", bin),
         design = "Naive method") %>% 
  rename(subgroup = bin)

## Vis ------

comb_df <- bind_rows(
  transform(results_q2,    design = "Method 1"),
  transform(results_q2_cf2, design = "Method 2"),
  naive
)

comb_df %>% 
  select(design, label,n, ate, se, ci_lo, ci_hi, tau_range) %>% 
  filter(design != "Naive method") %>% 
  arrange(label, design) %>% 
  mutate(across(c(ate, se), ~paste0(round(.x/1e3,1), "k"))) %>% 
  mutate(ci = paste0("[", round(ci_lo/1e3,2), "k; ", round(ci_hi/1e3, 2), "k]")) %>% 
  select(-c(ci_lo, ci_hi)) %>% 
  # group_by(label) %>% 
  gt::gt() %>% 
  gt::fmt_number(decimals = 0) %>% 
  gt::as_latex() %>% 
  pluck(1) %>% 
  cat() %>% 
  knitr::kable(format = "latex")

comb_df$label_full <- paste0("Q", comb_df$subgroup,
                             "\n(n = ", format(comb_df$n, big.mark = ","), ")")

p_q2_comp <- ggplot(comb_df,
                    aes(x = label, y = ate, ymin = ci_lo, ymax = ci_hi,
                        colour = str_wrap(design, width = 15))) +
  geom_hline(yintercept = ate_est, linetype = "dashed",
             colour = cml_grey, linewidth = 0.7) +
  geom_hline(yintercept = 0, linetype = "dotted",
             colour = "grey70", linewidth = 0.5) +
  geom_errorbar(width = 0.15, linewidth = 1.0,
                position = position_dodge(width = 0.4)) +
  geom_point(size = 3.2, position = position_dodge(width = 0.4)) +
  scale_colour_manual(values = cml_pal3) +
  #scale_y_continuous(labels = comma) +
  labs(
       x = NULL, y = "Estimated ATE (USD)", colour = NULL)+theme(legend.position  = "top")

ggsave(file.path(out_dir, "plot_q2_comparison.png"),
       plot = p_q2_comp, width = 8, height = 5, dpi = 150)

p_q2_comp




# Q3 -----------------


contributions <- (tau_hat - tau_bar)**2 +
  2 * (tau_hat - tau_bar) *
  (A / pi_hat - (1 - A) / (1 - pi_hat)) *
  (Y - (A * Q1_hat + (1 - A) * Q0_hat)) # Qa_hat is \hatE(Y|A=a, L)

eifs   <- contributions - mean(contributions)
vartau <- mean(contributions)

vartau + c(-1, 1) * 1.96 * sd(eifs) / sqrt(N)
sqrt(vartau)
sqrt(vartau + c(-1, 1) * 1.96 * sd(eifs) / sqrt(N))

cat("Var(tau):", vartau,
    "95% CI:", vartau + c(-1, 1) * 1.96 * sd(eifs) / sqrt(N),
    "\nSD(tau):", sqrt(vartau),
    "95% CI:", sqrt(vartau + c(-1, 1) * 1.96 * sd(eifs) / sqrt(N)))


## vis --------------

p_q3_eif_hist <- tibble(eifs, id = 1:length(eifs)) %>%
  mutate(extreme = factor(abs(eifs) > 5 * sd(eifs),
                          levels = c(FALSE, TRUE),
                          labels = c("Normal", "Extreme (> 5 SD)"))) %>%
  ggplot(aes(eifs, fill = extreme)) +
  geom_histogram(bins = 80, colour = "white") +
  geom_vline(xintercept = 0, linetype = "dotted", colour = cml_grey) +
  scale_fill_manual(values = c("Normal" = cml_blue,
                               "Extreme (> 5 SD)" = cml_red)) +
  scale_x_continuous(labels = waiver()) +
  labs(
       x = "EIF value", y = "Count", fill = NULL) +
theme(legend.position  = "top")
  

ggsave(file.path(out_dir, "plot_q3_eif_histogram.png"),
       plot = p_q3_eif_hist, width = 8, height = 5, dpi = 150)
p_q3_eif_hist




p_q3_eif_hist_zoom <- tibble(eifs, id = 1:length(eifs)) %>%
  mutate(extreme = factor(abs(eifs) > 5 * sd(eifs),
                          levels = c(FALSE, TRUE),
                          labels = c("Normal", "Extreme (> 5 SD)"))) %>%
  ggplot(aes(eifs, fill = extreme)) +
  geom_histogram(bins = 5000, colour = "white") +
  geom_vline(xintercept = 0, linetype = "dotted", colour = cml_grey) +
  scale_fill_manual(values = c("Normal" = cml_blue,
                               "Extreme (> 5 SD)" = cml_red)) +
  #scale_x_continuous(labels = waiver()) +
  labs(
       x = "EIF value", y = "Count", fill = NULL) +
theme(legend.position  = "none")+
  coord_cartesian(xlim = c(-500, 500) * 1e6)

ggsave(file.path(out_dir, "plot_q3_eif_histogram_zoom.png"),
       plot = p_q3_eif_hist_zoom, width = 8, height = 5, dpi = 150)
p_q3_eif_hist_zoom






p_q3_eif_ext <- tibble(eifs, id = 1:length(eifs)) %>%
  mutate(extreme = abs(eifs) > 5 * sd(eifs)) %>%
  ggplot(aes(id, eifs, colour = extreme)) +
  geom_point(alpha = 0.5, size = 0.8) +
  geom_hline(yintercept = c(-1, 1) * sd(eifs) * 5,
             colour = cml_red, linetype = "dashed") +
  scale_colour_manual(values = c(`FALSE` = cml_blue, `TRUE` = cml_red)) +
  #scale_y_continuous(labels = comma) +
  labs(
       x = "Observation index", y = "EIF value")+
theme(legend.position  = "top")

ggsave(file.path(out_dir, "plot_q3_eif_extreme.png"),
       plot = p_q3_eif_ext, width = 8, height = 5, dpi = 150)
p_q3_eif_ext

## extremes ---------
tibble(eifs, id = 1:length(eifs)) %>%
  mutate("eif>5sd" = abs(eifs) > 5 * sd(eifs)) %>%
  count(`eif>5sd`)


## sens ---------
idx <- which(abs(eifs) > 5 * sd(eifs))
contributions_sens <- contributions[-idx]

eifs_sens   <- contributions_sens - mean(contributions_sens)
vartau_sens <- mean(contributions_sens)

vartau_sens + c(-1, 1) * 1.96 * sd(eifs_sens) / sqrt(length(eifs_sens))
sqrt(vartau_sens)
sqrt(vartau_sens + c(-1, 1) * 1.96 * sd(eifs_sens) / sqrt(length(eifs_sens)))

cat("Sensitivity analysis:\nVar(tau):", vartau_sens,
    "95% CI:", vartau_sens + c(-1, 1) * 1.96 * sd(eifs_sens) / sqrt(length(eifs_sens)),
    "\nSD(tau):", sqrt(vartau_sens),
    "95% CI:", sqrt(vartau_sens + c(-1, 1) * 1.96 * sd(eifs_sens) / sqrt(length(eifs_sens))))


# Q4 ------------------

D <- tibble(Y_hat,
       pi_hat,
       W = (A - pi_hat)**2,
       Y_tilde = (Y - Y_hat) / (A - pi_hat),
       inc = pension$inc)

rmod <- mgcv::gam(Y_tilde ~ s(inc, bs = "cr"), weights = W, data = D)


# vis full

p_q4_fit <- broom::augment(rmod,
               newdata = tibble(inc = seq(min(pension$inc),
                                          max(pension$inc), by = 1e3))) %>%
  ggplot(aes(inc, .fitted)) +
  # geom_ribbon(aes(ymin = .fitted - 1.96 * .se.fit,
                  # ymax = .fitted + 1.96 * .se.fit),
              # fill = cml_blue, alpha = 0.25) +
  geom_line(colour = cml_red, linewidth = 1) +
  geom_hline(yintercept = ate_est, linetype = "dashed",
             colour = cml_grey, linewidth = 0.6) +
  annotate("text", x = max(pension$inc), y = ate_est,
           label = sprintf(" ATE = $%.0f", ate_est),
           colour = cml_grey, hjust = 1.05, vjust = -0.5, size = 3.5) +
  geom_rug(aes(y = NULL), data = D, colour = cml_blue, alpha = 0.3) +
  #scale_x_continuous(labels = scales::dollar_format()) +
  #scale_y_continuous(labels = scales::dollar_format()) +
  labs(
       x = "Household income (USD)", y = "Estimated CATE (USD)")

ggsave(file.path(out_dir, "plot_q4_cate_income.png"),
       plot = p_q4_fit, width = 9, height = 5, dpi = 150)
p_q4_fit


# histogram

p_q4_ytilde_hist <- D %>%
  mutate(extreme = factor(abs(Y_tilde) > 5 * sd(Y_tilde),
                          levels = c(FALSE, TRUE),
                          labels = c("Normal", "Extreme (> 5 SD)"))) %>%
  ggplot(aes(Y_tilde, fill = extreme)) +
  geom_histogram(bins = 300, colour = "white") +
  geom_vline(xintercept = 0, linetype = "dotted", colour = cml_grey) +
  scale_fill_manual(values = c("Normal" = cml_blue,
                               "Extreme (> 5 SD)" = cml_red)) +
  labs(
       x = "Pseudo-outcome value (USD)", y = "Count", fill = NULL)+theme(legend.position  = "top")+ coord_cartesian(xlim = c(-1, 1) * 1e6)

ggsave(file.path(out_dir, "plot_q4_ytilde_histogram.png"),
       plot = p_q4_ytilde_hist, width = 8, height = 5, dpi = 150)
p_q4_ytilde_hist


# extremes

p_q4_ytilde_ext <- D %>%
  mutate(id = row_number(),
         extreme = abs(Y_tilde) > 5 * sd(Y_tilde)) %>%
  ggplot(aes(id, Y_tilde, colour = extreme)) +
  geom_point(alpha = 0.5, size = 0.8) +
  geom_hline(yintercept = c(-1, 1) * 5 * sd(D$Y_tilde),
             colour = cml_red, linetype = "dashed") +
  scale_colour_manual(values = c(`FALSE` = cml_blue, `TRUE` = cml_red)) +
  #scale_y_continuous(labels = comma) +
  labs(
       x = "Observation index", y = "Pseudo-outcome value (USD)")

ggsave(file.path(out_dir, "plot_q4_ytilde_extreme.png"),
       plot = p_q4_ytilde_ext, width = 8, height = 5, dpi = 150)
p_q4_ytilde_ext



tibble(D$Y_tilde, id = 1:nrow(D)) %>%
  mutate("Ytilde>5sd" = abs(D$Y_tilde) > 5 * sd(D$Y_tilde)) %>%
  count(`Ytilde>5sd`)


## Sensitivity ----------
D_sens <- tibble(Y_hat,
       pi_hat,
       W = (A - pi_hat)**2,
       Y_tilde = (Y - Y_hat) / (A - pi_hat),
       inc = pension$inc) %>%
  filter(abs(Y_tilde) < 5 * sd(Y_tilde))

rmod_sens <- mgcv::gam(Y_tilde ~ s(inc, bs = "cr"), weights = W, data = D_sens)

grid_inc <- tibble(inc = seq(min(pension$inc), max(pension$inc), by = 1e3))

# ptotal <- broom::augment(rmod, newdata = grid_inc) %>%
#   ggplot(aes(inc, .fitted)) +
#   geom_line(colour = cml_red, linewidth = 1) +
#   geom_line(data = broom::augment(rmod_sens, newdata = grid_inc),
#             colour = cml_red, linewidth = 1, linetype = "dashed") +
#   geom_rug(aes(y = NULL), data = D, colour = cml_blue, alpha = 0.3) +
#   ## inset frame indicator
#   annotate("rect", xmin = -3000, xmax = 1e5, ymin = 0, ymax = 4e4,
#            fill = NA, colour = cml_grey, linewidth = 0.4) +
#   annotate("segment", x = 5e4, xend = 6e4, y = 4e4, yend = 110e3,
#            arrow = arrow(type = "closed", length = unit(0.25, "cm")),
#            colour = cml_grey) +
#   labs(
#        x = "Household income", y = "Estimated CATE")


ptotal <- broom::augment(rmod, newdata = grid_inc) %>% 
  mutate(Data = "Full") %>% 
  bind_rows(
    
    broom::augment(rmod_sens, newdata = grid_inc) %>% 
      mutate(Data = "No extremes")
    
  )%>%
  ggplot(aes(inc, .fitted, lty = Data)) +
  geom_line(colour = cml_red, linewidth = 1) +
  geom_rug(aes(x = inc), data = D, colour = cml_blue, alpha = 0.3, inherit.aes = F) +
  annotate("rect", xmin = -3000, xmax = 1e5, ymin = 0, ymax = 4e4,
           fill = NA, colour = cml_grey, linewidth = 0.4) +
  annotate("segment", x = 5e4, xend = 6e4, y = 4e4, yend = 110e3,
           arrow = arrow(type = "closed", length = unit(0.25, "cm")),
           colour = cml_grey) +
  labs(

    x = "Household income", y = "Estimated CATE") 


pdetail <- broom::augment(rmod, newdata = grid_inc) %>%
  ggplot(aes(inc, .fitted)) +
  geom_line(colour = cml_red, linewidth = 0.8) +
  geom_line(data = broom::augment(rmod_sens, newdata = grid_inc),
            colour = cml_red, linewidth = 0.8, linetype = "dashed") +
  coord_cartesian(xlim = c(0, 1e5), ylim = c(0, 4e4)) +
  labs(x = NULL, y = NULL) +
  theme(panel.background = element_rect(fill = "white", colour = cml_grey),
        plot.background  = element_rect(fill = "white", colour = NA))



p_q4_sens <- ptotal + inset_element(pdetail, 0.01, .4, .6, .99) 
  #scale_y_continuous(labels = scales::dollar_format()) &
  #scale_x_continuous(labels = scales::dollar_format())

ggsave(file.path(out_dir, "plot_q4_sensitivity.png"),
       plot = p_q4_sens, width = 9, height = 6, dpi = 150)
p_q4_sens

