# chunk: setup
knitr::opts_chunk$set(echo = FALSE, message = FALSE, warning = FALSE)

# chunk: library
library(hdm)
library(grf)
library(mgcv)
library(ggplot2)
library(dplyr)
library(knitr)
library(gridExtra)
library(scales)

# chunk: theme setting
theme_set(theme_bw(base_size = 10) +
  theme(
    plot.title    = element_text(size = 10, face = "bold"),
    plot.subtitle = element_text(size = 8,  color = "gray40"),
    axis.title    = element_text(size = 9)))

# chunk: data
# load data & define variables
data(pension)
Y <- pension$net_tfa # outcome
D <- pension$e401 # treatment, where D=1 is eligible, D=0 is ineligible
L <- model.matrix(~ age + inc + fsize + educ +
                         marr + twoearn + db + pira + hown,
                       data = pension) # design matrix for covariates
L <- L[, apply(L, 2, var) != 0] # delete covariates which maintain the same for all observations (var = 0)
n <- nrow(L) # 9915 observations
income <- pension$inc

# Task 1: Causal Forest
# chunk: causal-forest
set.seed(42)

cf <- causal_forest(X = L, Y = Y, W = D,
                    num.trees = 4000, tune.parameters = "all")
tau_hat   <- predict(cf, estimate.variance = TRUE)
cate      <- tau_hat$predictions

# quality checks
ps        <- cf$W.hat # propensity score
if_scores <- get_scores(cf) # influenc-function-based scores
ipw       <- ifelse(D == 1, 1/ps, 1/(1 - ps))

# chunk: overlap-plot

# plot 1: histogram for propensity score
p1 <- ggplot(
  data.frame(ps=ps, D=factor(D, labels=c("Ineligible","Eligible"))),
             aes(x=ps, fill=D)) +
  geom_histogram(bins=50, alpha=0.7, position="identity", color=NA) +
  geom_vline(xintercept=c(0.05,0.95), lty=2, color="red", linewidth=0.4) +
  scale_fill_manual(values=c("orange","blue")) +
  labs(title="Propensity scores", x=expression(hat(p)(L)), y="Count", fill=NULL) +
  theme(legend.key.size=unit(0.3,"cm"))

# plot 2: histogram for IPW weights (99.5% trim)
p2 <- ggplot(data.frame(w=ipw[ipw < quantile(ipw,0.995)]), aes(x=w)) +
  geom_histogram(bins=60, fill="steelblue", color=NA, alpha=0.85) +
  labs(title="IPW weights (99.5% trim)", x="IPW", y="Count")

# plot 3: histogram for influence scores
p3 <- ggplot(data.frame(phi=if_scores), aes(x=phi)) +
  geom_histogram(bins=80, fill="slategray", color=NA, alpha=0.85) +
  geom_vline(xintercept=mean(if_scores)+c(-3,3)*sd(if_scores),
             lty=2, color="red", linewidth=0.4) +
  labs(title="Influence functions", subtitle="±3 SD boundaries",
       x=expression(phi[i]), y="Count")

grid.arrange(p1, p2, p3, ncol=3)

# chunk: qc-stats
# For inserting values in text
ps_min  <- round(min(ps),3)
ps_max <- round(max(ps),3)
pct_ipw <- round(100*mean(ipw>50),1)
n_if    <- sum(abs(if_scores-mean(if_scores)) > 3*sd(if_scores))
pct_if  <- round(100*n_if/n,1)

# Task 1: Causal Forest | Results Interpretation (1a)
# chunk: ate-stats
ate_res <- average_treatment_effect(cf) # overall ATE

ate_est <- round(ate_res["estimate"],1)
ate_se  <- round(ate_res["std.err"],1)
ate_lo  <- round(ate_res["estimate"] - 1.96*ate_res["std.err"],1)
ate_hi  <- round(ate_res["estimate"] + 1.96*ate_res["std.err"],1)

# proportion on positive individual estimated CATE
pct_pos <- round(100*mean(cate>0),1) 

# distribution on CATE prediction
cate_q1 <- round(quantile(cate,0.25))
cate_q3 <- round(quantile(cate,0.75))
cate_sd <- round(sd(cate))

# chunk: cate-plots
df1 <- data.frame(cate=cate, income=income/1000)

# plot pa: distribution of estimated CATE distribution
pa <- ggplot(df1, aes(x=cate/1000)) +
  geom_histogram(aes(fill=after_stat(x>0)), bins=70, color=NA, alpha=0.9) +
  scale_fill_manual(values=c("FALSE"="orange","TRUE"="lightblue"), guide="none") +
  geom_vline(xintercept=mean(cate)/1000, lty=2, linewidth=0.6) +
  labs(title="Estimated CATE distribution", x=expression(hat(psi)(L[i])~"(×1000 USD)"), y="Count")

# plot pb: CATE vs income
pb <- ggplot(df1, aes(x=income, y=cate/1000)) +
  geom_point(alpha=0.05, size=0.5, color="steelblue") +
  geom_smooth(method="loess", span=0.4, color="darkred",
              fill="pink", linewidth=0.8) +
  geom_hline(yintercept=0, lty=2, linewidth=0.4) +
  labs(title="CATE vs income", x="Income (×1000 USD)",
       y=expression(hat(psi)(L[i])~"(×1000 USD)"))

grid.arrange(pa, pb, ncol=2)

# Task 1: Causal Forest | Is conditioning on additional covariates a problem? (1b)
# chunk: dag

# edges
edges <- data.frame(
  x    = c(3.8, 4.2, 2.0),
  y    = c(3.8, 3.8, 2.2),
  xend = c(2.2, 5.8, 5.8),
  yend = c(2.5, 2.5, 2.2)
)

# plot
ggplot() +
  # arrows
  geom_segment(data = edges,
               aes(x=x, y=y, xend=xend, yend=yend),
               arrow = arrow(length = unit(0.25, "cm"), type = "closed"),
               linewidth = 0.8, color = "gray") +
  
  # nodes
  geom_label(aes(x = 4.0, y = 4.0,
                 label = "L\n(observed baseline\ncovariates)"),
             fill = "yellow", color = "brown",
             fontface = "bold", size = 3.2,
             label.size = 0.4) +
  geom_label(aes(x = 2.0, y = 2.2,
                 label = "D\n(eligibility)"),
             fill = "lightblue", color = "blue",
             fontface = "bold", size = 3.2,
             label.size = 0.4) +
  geom_label(aes(x = 6.0, y = 2.2,
                 label = "Y\n(net financial assets)"),
             fill = "lightblue", color = "blue",
             fontface = "bold", size = 3.2,
             label.size = 0.4) +
  
  # edge labels
  annotate("text", x = 2.8, y = 3.25, label = "L → D",
           size = 3, color = "gray30", fontface = "italic", angle = 35) +
  annotate("text", x = 5.1, y = 3.25, label = "L → Y",
           size = 3, color = "gray30", fontface = "italic", angle = -35) +
  annotate("text", x = 4.0, y = 2.45, label = "D → Y",
           size = 3.1, color = "darkblue", fontface = "bold.italic") +
  
  coord_cartesian(xlim = c(0.8, 7.2), ylim = c(0.6, 4.8)) +
  theme_void()

# Task 2: Subgroup Analysis
# chunk: subgroup
quartile  <- ntile(cate, 4) # divide `cate` into 4 groups

results_q <- lapply(1:4, function(q) {
  idx <- which(quartile == q)
  r   <- average_treatment_effect(cf, subset=idx)
  data.frame(Group=q, n=length(idx),
             ATE      = round(r["estimate"],1),
             SE       = round(r["std.err"],1),
             CI_lower = round(r["estimate"] - 1.96*r["std.err"],1),
             CI_upper = round(r["estimate"] + 1.96*r["std.err"],1))
})

# create subgroup summary data frame
df_sub <- do.call(rbind, results_q)
row.names(df_sub) <- NULL

# chunk: subgroup-table
# print df_sub into a nice table
kable(df_sub,
      col.names = c("Group","n","ATE (USD)","SE","95% CI lower","95% CI upper"),
      caption   = "AIPW estimates of the ATE within each CATE quartile.",
      align     = "rrrrrr")

# chunk: subgroup-plot
# visualization on the previous subgroup summary table
ggplot(df_sub, aes(x=factor(Group), y=ATE)) +
  geom_hline(yintercept=0, lty=2, color="gray60") +
  geom_errorbar(aes(ymin=CI_lower, ymax=CI_upper),
                width=0.12, linewidth=0.8, color="steelblue") +
  geom_point(size=3.5, color="steelblue") +
  geom_text(aes(label=paste0("n=",n)), vjust=-1.3, size=2.8, color="gray40") +
  scale_y_continuous(labels=comma) +
  labs(x="CATE quartile (1 = lowest predicted, 4 = highest)",
       y="ATE [USD]", title="ATE per CATE quartile")

# chunk: subgroup-stats
g <- df_sub
ratio <- round(g$ATE[4] / g$ATE[1], 1)

# Task 3: Evidence of Effect Heterogeneity
# chunk: EIF
set.seed(2026)

ps_t  <- pmin(pmax(ps, 0.01), 0.99)
ps0_t <- 1 - ps_t

# Cross-fitted outcome regressions (10-fold)
K3      <- 10
folds3  <- sample(rep(1:K3, length.out = n))
mu1_hat <- numeric(n)
mu0_hat <- numeric(n)

for (k in 1:K3) {
  tr  <- which(folds3 != k)
  te  <- which(folds3 == k)
  tr1 <- tr[D[tr] == 1]
  tr0 <- tr[D[tr] == 0]
  rf1 <- regression_forest(L[tr1, ], Y[tr1], num.trees = 1000)
  rf0 <- regression_forest(L[tr0, ], Y[tr0], num.trees = 1000)
  mu1_hat[te] <- predict(rf1, L[te, ])$predictions
  mu0_hat[te] <- predict(rf0, L[te, ])$predictions
}

mu_hat   <- D * mu1_hat + (1 - D) * mu0_hat
y_resid  <- Y - mu_hat
ipw_term <- D / ps_t - (1 - D) / ps0_t
eif      <- (cate - ate_est)^2 + 2 * (cate - ate_est) * ipw_term * y_resid

# chunk: sigma2-ci
s2_hat <- mean(eif)
s2_se  <- sd(eif) / sqrt(n)
s2_ci  <- s2_hat + c(-1, 1) * 1.96 * s2_se
sd_imp <- round(sqrt(max(s2_hat, 0)))

# chunk: sigma2-stats
s2_lo  <- format(round(s2_ci[1]), big.mark = ",")
s2_hi  <- format(round(s2_ci[2]), big.mark = ",")
s2_pt  <- format(round(s2_hat),   big.mark = ",")
sd_pct <- round(sd_imp / ate_est * 100)

# EIF diagnostics
n_eif_out  <- sum(abs(eif - mean(eif)) > 3 * sd(eif))
pct_eif    <- round(100 * n_eif_out / n, 1)
eif_drop   <- mean(eif[abs(eif - mean(eif)) <= 3 * sd(eif)])
s2_drop    <- round(eif_drop)

# Implied CATE range under normality
cate_p10   <- format(round(ate_est - 1.28 * sd_imp), big.mark = ",")
cate_p90   <- format(round(ate_est + 1.28 * sd_imp), big.mark = ",")

# Task 3: Evidence of Effect Heterogeneity | Results and interpretation
# chunk: sigma2-interp
if (s2_ci[1] > 0) {
  stat_msg <- "The confidence interval lies entirely above zero, providing formal statistical evidence that the treatment effect is not homogeneous across households."
} else {
  stat_msg <- "The confidence interval includes zero, so we cannot formally reject treatment effect homogeneity at the 5% level; however, the positive point estimate remains consistent with the heterogeneity patterns observed in Tasks 1 and 2."
}

# Task 4: Conditional Effect by Income
# chunk: crossfit
set.seed(42)
K       <- 10
folds   <- sample(rep(1:K, length.out = n))
Y_tilde <- numeric(n)
D_tilde <- numeric(n)
e_hat4  <- numeric(n)   # store propensities for diagnostics

for (k in 1:K) {
  tr <- which(folds != k); te <- which(folds == k)
  rfY <- regression_forest(L[tr,], Y[tr], num.trees = 1000, tune.parameters = "all")
  rfD <- regression_forest(L[tr,], D[tr], num.trees = 1000, tune.parameters = "all")
  q_k           <- predict(rfY, L[te,])$predictions
  p_k_raw       <- predict(rfD, L[te,])$predictions
  p_k           <- pmin(pmax(p_k_raw, 0.01), 0.99)
  e_hat4[te]    <- p_k
  Y_tilde[te]   <- Y[te] - q_k
  D_tilde[te]   <- D[te] - p_k
}

# chunk: gam-fit
fit_gam <- gam(Y_tilde ~ s(income, by = D_tilde, bs = "cr", k = 10),
               data = data.frame(Y_tilde, D_tilde, income))

grid_inc <- seq(quantile(income, .05), quantile(income, .92), length.out = 300)
pr  <- predict(fit_gam,
               newdata = data.frame(income = grid_inc, D_tilde = rep(1, 300)),
               se.fit  = TRUE)
df4 <- data.frame(income = grid_inc,
                  tau    = pr$fit,
                  tau_lo = pr$fit - 1.96 * pr$se.fit,
                  tau_hi = pr$fit + 1.96 * pr$se.fit)
edf_val <- round(summary(fit_gam)$edf, 1)

tau_obs <- predict(fit_gam,
                   newdata = data.frame(income = income, D_tilde = rep(1, n)))

# chunk: t4-diagnostics
## ---- Propensity diagnostics ----
ps4_min    <- round(min(e_hat4), 3)
ps4_max    <- round(max(e_hat4), 3)
ps4_med    <- round(median(e_hat4), 3)
pct_trim   <- round(100 * mean(e_hat4 <= 0.01 | e_hat4 >= 0.99), 2)

## ---- IPW max-to-mean ratios ----
ipw4_t <- (1 / e_hat4)[D == 1]
ipw4_c <- (1 / (1 - e_hat4))[D == 0]
ipw4_t_ratio <- round(max(ipw4_t) / mean(ipw4_t), 1)
ipw4_c_ratio <- round(max(ipw4_c) / mean(ipw4_c), 1)

## ---- Kish effective sample size (R-learner second stage) ----
w_kish <- D_tilde^2
kish_ess <- round((sum(w_kish))^2 / sum(w_kish^2))

## ---- AIPW ATE cross-check (reuse mu1_hat, mu0_hat from Task 3) ----
e4_trim  <- pmin(pmax(e_hat4, 0.01), 0.99)
psi4 <- mu1_hat - mu0_hat +
        D / e4_trim       * (Y - mu1_hat) -
        (1 - D) / (1 - e4_trim) * (Y - mu0_hat)
ATE4_hat <- mean(psi4)
ATE4_se  <- sd(psi4) / sqrt(n)
ATE4_lo  <- round(ATE4_hat - 1.96 * ATE4_se)
ATE4_hi  <- round(ATE4_hat + 1.96 * ATE4_se)
ATE4_hat_r <- round(ATE4_hat)

tau_mean_r  <- round(mean(tau_obs))
discrepancy <- round(abs(tau_mean_r - ATE4_hat_r))
disc_pct    <- round(100 * abs(tau_mean_r - ATE4_hat_r) / abs(ATE4_hat_r), 1)

## ---- Sensitivity: drop top 1% most influential ----
psi4_cent <- psi4 - ATE4_hat
top1_idx  <- order(abs(psi4_cent), decreasing = TRUE)[1:round(0.01 * n)]
ATE4_drop <- round(mean(psi4[-top1_idx]))

## ---- Seed stability: two additional seeds ----
get_tau_mean <- function(seed_val) {
  set.seed(seed_val)
  folds_s <- sample(rep(1:K, length.out = n))
  Yt_s <- numeric(n); Dt_s <- numeric(n)
  for (k in 1:K) {
    tr <- which(folds_s != k); te <- which(folds_s == k)
    rfY_s <- regression_forest(L[tr,], Y[tr], num.trees = 500)
    rfD_s <- regression_forest(L[tr,], D[tr], num.trees = 500)
    Yt_s[te] <- Y[te] - predict(rfY_s, L[te,])$predictions
    Dt_s[te] <- D[te] - pmin(pmax(predict(rfD_s, L[te,])$predictions, 0.01), 0.99)
  }
  fit_s <- gam(Yt_s ~ s(income, by = Dt_s, bs = "cr", k = 10),
               data = data.frame(Yt_s, Dt_s, income))
  round(mean(predict(fit_s, newdata = data.frame(income = income, Dt_s = rep(1, n)))))
}
tau_seed7  <- get_tau_mean(7)
tau_seed99 <- get_tau_mean(99)

## ---- Decile table ----
deciles    <- quantile(income, probs = seq(0.1, 0.9, by = 0.1))
pr_dec     <- predict(fit_gam,
                      newdata = data.frame(income = deciles,
                                           D_tilde = rep(1, 9)),
                      se.fit = TRUE)
decile_tbl <- data.frame(
  Decile = paste0("D", 1:9),
  `Income (USD)` = format(round(deciles), big.mark = ","),
  `tau-hat (USD)` = format(round(pr_dec$fit), big.mark = ","),
  `95% CI`       = paste0("[",
                           format(round(pr_dec$fit - 1.96 * pr_dec$se.fit), big.mark = ","),
                           ", ",
                           format(round(pr_dec$fit + 1.96 * pr_dec$se.fit), big.mark = ","),
                           "]"),
  check.names = FALSE
)

## ---- Point estimates for in-text use ----
# Estimates at each decile
tau_d1 <- round(pr_dec$fit[1]); tau_d2 <- round(pr_dec$fit[2])
tau_d3 <- round(pr_dec$fit[3]); tau_d5 <- round(pr_dec$fit[5])
tau_d7 <- round(pr_dec$fit[7]); tau_d9 <- round(pr_dec$fit[9])

# CI bounds
ci_d3_lo <- round(pr_dec$fit[3] - 1.96 * pr_dec$se.fit[3])
ci_d5_lo <- round(pr_dec$fit[5] - 1.96 * pr_dec$se.fit[5])
ci_d5_hi <- round(pr_dec$fit[5] + 1.96 * pr_dec$se.fit[5])
ci_d9_lo <- round(pr_dec$fit[9] - 1.96 * pr_dec$se.fit[9])
ci_d9_hi <- round(pr_dec$fit[9] + 1.96 * pr_dec$se.fit[9])

# Income labels
inc_d1 <- format(round(deciles[1]), big.mark = ",")
inc_d2 <- format(round(deciles[2]), big.mark = ",")
inc_d3 <- format(round(deciles[3]), big.mark = ",")
inc_d5 <- format(round(deciles[5]), big.mark = ",")
inc_d7 <- format(round(deciles[7]), big.mark = ",")
inc_d9 <- format(round(deciles[9]), big.mark = ",")

# Marginal effect: slope of tau over d5–d9 range ($ per $ income)
marginal_eff <- round((pr_dec$fit[9] - pr_dec$fit[5]) /
                      (deciles[9]    - deciles[5]), 2)

# Lowest decile where CI clearly excludes zero
first_sig <- which(pr_dec$fit - 1.96 * pr_dec$se.fit > 0)[1]
inc_sig   <- if (!is.na(first_sig)) format(round(deciles[first_sig]), big.mark = ",") else "—"

## ---- Mean residuals ----
mY <- round(mean(Y_tilde), 1)
mD <- round(mean(D_tilde), 4)

# chunk: gam-plot
ggplot(df4, aes(x = income, y = tau)) +
  geom_ribbon(aes(ymin = tau_lo, ymax = tau_hi), alpha = 0.15, fill = "steelblue") +
  geom_line(color = "steelblue", linewidth = 0.9) +
  geom_hline(yintercept = 0, lty = 2, color = "grey40", linewidth = 0.5) +
  scale_x_continuous(labels = dollar_format(scale = 1),
                     breaks = c(25000, 50000, 75000, 100000)) +
  scale_y_continuous(labels = dollar_format(scale = 1),
                     breaks = c(0, 10000, 20000, 30000)) +
  labs(x = "Income (USD)", y = expression(hat(tau)(income)),
       title    = "CATE of 401(k) eligibility on net financial assets",
       subtitle = "R-learner with full confounder adjustment; CATE as a function of income only") +
  theme_bw(base_size = 10) +
  theme(plot.subtitle = element_text(size = 8, color = "grey40"))
