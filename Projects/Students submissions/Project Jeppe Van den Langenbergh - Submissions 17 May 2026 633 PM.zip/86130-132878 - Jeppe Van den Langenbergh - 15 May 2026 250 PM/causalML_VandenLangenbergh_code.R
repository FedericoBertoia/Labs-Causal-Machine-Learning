knitr::opts_chunk$set(
  echo = TRUE, 
  warning = FALSE, 
  message = FALSE,
  collapse = TRUE,
  strip.white = TRUE,
  fig.align = "center"
)
set.seed(6767)
library(hdm)
library(grf)
library(dplyr)
library(tidyr)
library(ggplot2)
library(patchwork)
library(SuperLearner)
library(pROC)
library(gbm)
library(mgcv)
library(scales)
library(splines)
library(DiagrammeR)

data(pension)

# Preprocessing
df <- pension %>% select(net_tfa, e401, pira, age, inc, fsize, educ, marr, twoearn, db, hown) %>%
  drop_na()

stopifnot(all(colSums(is.na(df)) == 0))

Y <- df$net_tfa # outcome: net financial assets
W <- df$e401 # treatment: 401(k) eligibility
X <- df %>% select(-e401, -net_tfa) # covariates

N <- nrow(df)
n_folds <- 5

cat(sprintf("N = %d  |  Eligible: %d (%.1f%%)  |  Mean net_tfa: $%.0f\n", N, sum(W), 100 * mean(W), mean(Y)))

# Cross-fitting setup
fold_id <- sample(rep(1:n_folds, length.out = N))
folds <- split(seq_len(N), fold_id)

SL.library <- c("SL.mean", "SL.glm", "SL.ranger", "SL.gam", "SL.earth")


# Nuisance 1: propensity score E[W | X]
W_hat <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)
  
  sl_W <- SuperLearner(
    Y          = W[train],
    X          = X[train, ],
    family     = binomial(),
    SL.library = SL.library,
    method     = "method.NNLS",
    cvControl  = list(V = 5)
  )
  
  W_hat[test] <- predict(sl_W, newdata = X[test, ])$pred
}

# Trim propensities for numerical stability (positivity safeguard)
eps   <- 0.01
W_hat <- pmin(pmax(W_hat, eps), 1 - eps)

# Diagnostics
cat(sprintf("\nPropensity score | MSE: %.4f | AUC: %.4f\n", 
            mean((W - W_hat)^2), as.numeric(auc(roc(W, W_hat, quiet = TRUE)))))
cat(sprintf("Range: [%.3f, %.3f]\n", min(W_hat), max(W_hat)))
cat(sprintf("Below 0.05 or above 0.95: %.2f%%\n", 100 * mean(W_hat < 0.05 | W_hat > 0.95)))
cat(sprintf("Below 0.01 or above 0.99 (clipped): %d obs\n", sum(W_hat <= eps | W_hat >= 1 - eps)))

# ROC curve for propensity score model
roc_e401_cf <- roc(W, W_hat, quiet = TRUE)
p_roc <- ggplot(data.frame(fpr = 1 - roc_e401_cf$specificities, tpr = roc_e401_cf$sensitivities), 
                aes(x = fpr, y = tpr)) +
  geom_line(colour = "steelblue") + geom_abline(linetype = "dashed") +
  labs(title = "ROC Curve", x = "FPR", y = "TPR")

# p_roc

# Nuisance 2: outcome model E[Y | X]
Y_hat <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)
  
  sl_Y <- SuperLearner(
    Y          = Y[train],
    X          = X[train, ],
    family     = gaussian(),
    SL.library = SL.library,
    method     = "method.NNLS",
    cvControl  = list(V = 5)
  )
  
  Y_hat[test] <- predict(sl_Y, newdata = X[test, ])$pred
}

mse_Y <- mean((Y - Y_hat)^2)
r2_Y  <- 1 - mse_Y / var(Y)
cat(sprintf("Outcome model | MSE: %.0f | R²: %.4f\n", mse_Y, r2_Y))

# Causal forest
cf <- causal_forest(
  X               = as.matrix(X),
  Y               = Y,
  W               = W,
  Y.hat           = Y_hat,
  W.hat           = W_hat,
  tune.parameters = "all",
  num.trees       = 4000,
  seed            = 6767)

# ATE and confidence interval
ate <- average_treatment_effect(cf, target.sample = "all")
att <- average_treatment_effect(cf, target.sample = "treated")
atc <- average_treatment_effect(cf, target.sample = "control")

cat("\n══ RESULTS ═════════════════════════════════════════════════════════════\n")
cat(sprintf("ATE = $%.0f  (95%% CI: $%.0f – $%.0f)\n",
            ate["estimate"],
            ate["estimate"] - 1.96 * ate["std.err"],
            ate["estimate"] + 1.96 * ate["std.err"]))
cat(sprintf("ATT = $%.0f  (95%% CI: $%.0f – $%.0f)\n",
            att["estimate"],
            att["estimate"] - 1.96 * att["std.err"],
            att["estimate"] + 1.96 * att["std.err"]))
cat(sprintf("ATC = $%.0f  (95%% CI: $%.0f – $%.0f)\n",
            atc["estimate"],
            atc["estimate"] - 1.96 * atc["std.err"],
            atc["estimate"] + 1.96 * atc["std.err"]))

# Individual CATEs (out-of-bag)
cate_out <- predict(cf, estimate.variance = TRUE)
cate <- cate_out$predictions
cate_se <- sqrt(cate_out$variance.estimates)

cat(sprintf("\nCATEs | Min: $%.0f | Median: $%.0f | Max: $%.0f | SD: $%.0f\n",
            min(cate), median(cate), max(cate), sd(cate)))

# Quality checks

## Calibration test: does the forest capture real heterogeneity?
cat("\n── Calibration test ─────────────────────────────────────────────────────\n")
print(test_calibration(cf))

## Influence function diagnostics
scores <- get_scores(cf)
n_extreme <- sum(abs(scores - median(scores)) > 3 * IQR(scores))
cat(sprintf("\nInfluence functions | Median: $%.0f | IQR: $%.0f | Extreme obs: %d (%.1f%%)\n",
            median(scores), IQR(scores), n_extreme, 100 * n_extreme / N))

## Best linear projection: formal test of heterogeneity drivers
cat("\n── Best linear projection of CATE on covariates ─────────────────────────\n")
blp <- best_linear_projection(cf, A = as.matrix(X))
print(blp)

# Variable importance
vi <- variable_importance(cf)
vi_df <- data.frame(Variable   = colnames(X), Importance = as.numeric(vi)) %>%
  arrange(desc(Importance))

cat("\nVariable importance:\n"); print(as.matrix(vi_df))

# Informative visualisations
plot_df <- data.frame(
  cate    = cate,
  cate_se = cate_se,
  score   = scores,
  inc     = X$inc,
  age     = X$age,
  ira     = factor(X$pira, levels = c(0, 1), labels = c("No IRA",   "Has IRA")),
  hown    = factor(X$hown, levels = c(0, 1), labels = c("Renter",   "Homeowner")),
  W       = W,
  W_hat   = W_hat)

theme_set(theme_minimal(base_size = 11))

## Panel A: CATE distribution with ATE marked
pA <- ggplot(plot_df, aes(x = cate)) +
  geom_histogram(aes(y = after_stat(density)), bins = 50,
                 fill = "steelblue", colour = "white", alpha = 0.85) +
  geom_vline(xintercept = ate["estimate"], colour = "tomato",
             linewidth = 1, linetype = "dashed") +
  annotate("text", x = ate["estimate"], y = Inf,
           label = sprintf(" ATE = $%.0f", ate["estimate"]),
           hjust = 0, vjust = 1.5, colour = "tomato", size = 3.2) +
  labs(title = "A. Distribution of CATEs",
       x = "Estimated treatment effect (USD)", y = "Density")

## Panel B: CATE vs income with GAM smoother (fast on ~10k points)
pB <- ggplot(plot_df, aes(x = inc, y = cate, colour = ira)) +
  geom_point(alpha = 0.12, size = 0.6) +
  geom_smooth(method = "gam", formula = y ~ s(x), se = TRUE, linewidth = 1) +
  geom_hline(yintercept = 0, linetype = "dotted", colour = "grey50") +
  scale_colour_manual(values = c("steelblue", "tomato")) +
  labs(title = "B. CATE by income",
       x = "Income (USD)", y = "CATE (USD)", colour = NULL) +
  theme(legend.position = "top")

## Panel C: CATE by age quartile (boxplot)
plot_df$age_q <- cut(plot_df$age,
                     breaks = quantile(plot_df$age, probs = 0:4 / 4),
                     include.lowest = TRUE,
                     labels = c("Q1\n(youngest)", "Q2", "Q3", "Q4\n(oldest)"))

pC <- ggplot(plot_df, aes(x = age_q, y = cate, fill = age_q)) +
  geom_boxplot(alpha = 0.7, outlier.size = 0.4, outlier.alpha = 0.3) +
  geom_hline(yintercept = ate["estimate"], colour = "tomato",
             linewidth = 0.8, linetype = "dashed") +
  scale_fill_brewer(palette = "Blues") +
  labs(title = "C. CATE by age quartile",
       x = "Age quartile", y = "CATE (USD)") +
  theme(legend.position = "none")

## Panel D: Variable importance
pD <- ggplot(vi_df, aes(x = reorder(Variable, Importance), y = Importance)) +
  geom_col(fill = "steelblue", width = 0.7) +
  coord_flip() +
  labs(title = "D. Variable importance",
       x = NULL, y = "Importance (splitting frequency)")

## Panel E: Propensity score overlap (positivity check)
pE <- ggplot(plot_df, aes(x = W_hat, fill = factor(W))) +
  geom_histogram(bins = 40, alpha = 0.65, position = "identity") +
  scale_fill_manual(values = c("steelblue", "tomato"),
                    labels = c("Ineligible (W=0)", "Eligible (W=1)")) +
  labs(title    = "E. Propensity score overlap",
       subtitle = "Positivity check",
       x = "Estimated P(W=1 | X)", y = "Count", fill = NULL) +
  theme(legend.position = "top")

## Panel F: Influence function distribution (stability check)
pF <- ggplot(plot_df, aes(x = score)) +
  geom_histogram(bins = 50, fill = "steelblue", colour = "white", alpha = 0.85) +
  geom_vline(xintercept = median(scores), colour = "tomato",
             linewidth = 0.8, linetype = "dashed") +
  labs(title    = "F. Influence functions (scores)",
       subtitle = "Stability check — few extreme values is good",
       x = "Score value (USD)", y = "Count")

## Combine all panels
# Combine the plots and move the legend to the bottom to prevent overlapping
combined <- (pA | pB | pC) / (pD | pE | pF) +
  theme_minimal(base_size = 2) + # Reduces overall text size in plots
  theme(
    legend.position = "bottom",
    legend.text = element_text(size = 2),
    legend.title = element_text(size = 2),
    legend.box = "horizontal"
  )

print(combined)

# Subgroup ATEs (supplementary interpretation)
subgroups <- list(
  "Low income (bot. third)" = X$inc < quantile(X$inc, 1/3),
  "High income (top third)" = X$inc >= quantile(X$inc, 2/3),
  "Young (age < 35)" = X$age < 35,
  "Older (age >= 50)" = X$age >= 50,
  "IRA participant" = X$pira == 1,
  "No IRA" = X$pira == 0,
  "Homeowner" = X$hown == 1,
  "Renter" = X$hown == 0)

cat("\n── Subgroup ATEs ────────────────────────────────────────────────────────\n")
for (nm in names(subgroups)) {idx <- subgroups[[nm]]
  sg  <- average_treatment_effect(cf, target.sample = "all", subset = idx)
  cat(sprintf("%-28s  N=%4d  ATE=$%6.0f  95%%CI=($%6.0f, $%6.0f)\n",
              nm, sum(idx), sg["estimate"],
              sg["estimate"] - 1.96 * sg["std.err"],
              sg["estimate"] + 1.96 * sg["std.err"]))
}

# grViz(" digraph DAG { graph [rankdir = LR, splines = curved] node [shape = ellipse, fontname = Helvetica, fontsize = 12] U [label = 'U\n(unobs. savings pref.)', style = dashed] L [label = 'L\n(age, educ, ...)'] Inc [label = 'Income'] W [label = 'W\n(401k eligibility)'] Y [label = 'Y\n(net financial assets)'] L -> Inc L -> Y Inc -> W Inc -> Y W -> Y U -> Y } ")

knitr::include_graphics("dag.png")

# GATES: Group Average Treatment Effects
# Subgroups defined by ntile() on causal forest CATE predictions

gates_df <- data.frame(cate = cate, subgroup = ntile(cate, 4))

group_labels <- c("Q1 (lowest)", "Q2", "Q3", "Q4 (highest)")

gates_results <- lapply(1:4, function(g) {
  idx   <- gates_df$subgroup == g
  ate_g <- average_treatment_effect(cf, target.sample = "all", subset = idx)
  data.frame(
    Subgroup = group_labels[g],
    N        = sum(idx),
    ATE      = ate_g["estimate"],
    SE       = ate_g["std.err"],
    CI_lo    = ate_g["estimate"] - 1.96 * ate_g["std.err"],
    CI_hi    = ate_g["estimate"] + 1.96 * ate_g["std.err"]
  )
})

gates_tbl <- do.call(rbind, gates_results)
rownames(gates_tbl) <- NULL
gates_tbl$Subgroup  <- factor(gates_tbl$Subgroup, levels = group_labels)

cat("\n══ GATES: Group Average Treatment Effects ═══════════════════════════════\n")
cat(sprintf("%-14s  %5s  %8s  %7s  %22s\n", "Subgroup", "N", "ATE ($)", "SE ($)", "95% CI"))
cat(strrep("─", 62), "\n")
for (i in 1:4) {
  r <- gates_tbl[i, ]
  cat(sprintf("%-14s  %5d  %8.0f  %7.0f  ($%7.0f – $%7.0f)\n",
              r$Subgroup, r$N, r$ATE, r$SE, r$CI_lo, r$CI_hi))
}
cat(strrep("─", 62), "\n")

# Formal heterogeneity checks based on GATES

# Q4 − Q1 difference (groups are disjoint -> SEs add in quadrature)
diff_q4_q1 <- gates_tbl$ATE[4] - gates_tbl$ATE[1]
se_diff <- sqrt(gates_tbl$SE[4]^2 + gates_tbl$SE[1]^2)
z_diff <- diff_q4_q1 / se_diff
p_diff <- 2 * pnorm(-abs(z_diff))

cat(sprintf("\nQ4 − Q1 = $%.0f  (95%% CI: $%.0f – $%.0f)  z = %.2f  p = %.4f\n",
            diff_q4_q1,
            diff_q4_q1 - 1.96 * se_diff,
            diff_q4_q1 + 1.96 * se_diff,
            z_diff, p_diff))

# grf's rank-average treatment effect (doubly robust test of monotone ordering by predicted CATE)
cat("\n── rank_average_treatment_effect ────────────────────────────────────────\n")
rate <- rank_average_treatment_effect(cf, cate)
print(rate)

# Plot
ggplot(gates_tbl, aes(x = Subgroup, y = ATE)) +
  geom_hline(yintercept = ate["estimate"],
             linetype = "dashed", colour = "tomato", linewidth = 0.8) +
  geom_hline(yintercept = 0,
             linetype = "dotted", colour = "grey60") +
  geom_errorbar(aes(ymin = CI_lo, ymax = CI_hi),
                width = 0.12, colour = "grey40", linewidth = 0.7) +
  geom_point(size = 4, colour = "steelblue") +
  annotate("text", x = 0.55, y = ate["estimate"],
           label = sprintf("Overall ATE = $%.0f", ate["estimate"]),
           colour = "tomato", size = 3.2, vjust = -0.5, hjust = 0) +
  scale_y_continuous(labels = dollar_format()) +
  labs(
    title    = "GATES: Average treatment effect by predicted CATE subgroup",
    subtitle = "Subgroups defined by ntile(CATE, 4)  |  error bars = 95% CI  |  dashed = overall ATE",
    x        = "Subgroup (causal forest CATE quartile)",
    y        = "Estimated ATE (USD)"
  ) +
  theme_minimal(base_size = 11) +
  theme(panel.grid.minor = element_blank())


# Inputs from Q1/Q2
#  cate: τ_hat(L) = E[Y¹-Y⁰|L] (OOB causal-forest predictions)
#  W_hat: ê(L) = P(W = 1 | L) (cross-fitted propensity)
#  Y_hat: m̂(L) = E[Y | L] (cross-fitted marginal outcome)
#  W: treatment vector (e401)
#  Y: outcome vector (net_tfa)
#  X, df, N, folds, n_folds, SL.library  also reused from Q1

# Step 0: Trim propensities for numerical stability
eps   <- 0.01
W_hat <- pmin(pmax(W_hat, eps), 1 - eps)

# Step 1: Cross-fitted nuisance μ_hat(W, L) = E[Y | W, L]
# We fit μ(W,L) directly, so its estimation error doesn't covary mechanically with τ_hat in the EIF.
set.seed(6767)
mu_hat <- numeric(N)

for (k in 1:n_folds) {
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)
  
  XW_train <- cbind(X[train, ], W = W[train])
  XW_test  <- cbind(X[test , ], W = W[test ])
  
  sl_mu <- SuperLearner(
    Y          = Y[train],
    X          = XW_train,           # W included as a regressor
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS",
    cvControl  = list(V = 5)
  )
  
  mu_hat[test] <- predict(sl_mu, newdata = XW_test)$pred
}

# Quick diagnostic
mse_mu <- mean((Y - mu_hat)^2)
r2_mu  <- 1 - mse_mu / var(Y)
cat(sprintf("mu_hat(W,L) fit | MSE: %.0f | R²: %.4f\n", mse_mu, r2_mu))

# Step 2: Plug-in for θ = E[Y¹ - Y⁰]
tau_bar <- ate["estimate"]
cat(sprintf("Plug-in theta_hat(mean of tau_hat): %.0f\n", tau_bar))

# Step 3: Efficient influence function
ipw_aug <- W / W_hat - (1 - W) / (1 - W_hat)

eif <- (cate - tau_bar)^2 + 2 * (cate - tau_bar) * ipw_aug * (Y - mu_hat)

# Step 4: Point estimate, SE, CI, Wald test
sigma2_hat <- mean(eif)
se_sigma2 <- sd(eif) / sqrt(N)
ci_sigma2 <- sigma2_hat + c(-1, 1) * 1.96 * se_sigma2

z_stat <- sigma2_hat / se_sigma2
p_one  <- 1 - pnorm(z_stat) # one-sided: variance is non-negative

cat("\n══ Q3. Variance of the CATE ═════════════════════════════════════════════\n")
cat(sprintf("sigma_hat² = %.3e (USD²)\n", sigma2_hat))
cat(sprintf("SE(sigma_hat²)  = %.3e\n", se_sigma2))
cat(sprintf("95%% CI = [%.3e , %.3e]\n", ci_sigma2[1], ci_sigma2[2]))
cat(sprintf("Wald z = %.2f,  one-sided p = %.4f  (H0: sigma² = 0)\n", z_stat, p_one))

# Report σ_hat in dollars (interpretable scale)
cat(sprintf("\nsigma_hat  = $%.0f (95%% CI: $%.0f – $%.0f)\n",
            sqrt(max(sigma2_hat,    0)),
            sqrt(max(ci_sigma2[1],  0)),
            sqrt(max(ci_sigma2[2],  0))))

# Compare to naive plug-in (biased upward by estimation noise in τ̂)
cat(sprintf("\nNaive var(tau_hat) = %.3e   vs.   EIF sigma_hat² = %.3e\n",
            var(cate), sigma2_hat))
cat(sprintf("Naive sd(tau_hat) = $%.0f vs. EIF sigma_hat = $%.0f\n",
            sd(cate), sqrt(max(sigma2_hat, 0))))

# Quality checks

# EIF distribution: extreme points inflate SE
n_extreme_eif <- sum(abs(eif - median(eif)) > 3 * IQR(eif))
cat(sprintf("\nEIF | median: %.2e | IQR: %.2e | extreme obs: %d (%.1f%%)\n",
            median(eif), IQR(eif), n_extreme_eif, 100 * n_extreme_eif / N))

par(mfrow = c(1, 3))

# Plot 1: Propensity score overlap
ps_df <- data.frame(ps = W_hat, W = factor(W, levels = c(0,1), labels = c("Not eligible", "Eligible")))
plot(density(ps_df$ps[ps_df$W == "Not eligible"]), col = "steelblue", lwd = 2,
     main = "Positivity check", xlab = expression(hat(e)(L)), ylab = "Density")
lines(density(ps_df$ps[ps_df$W == "Eligible"]), col = "tomato", lwd = 2)
legend("topright", legend = c("Not eligible", "Eligible"), col = c("steelblue", "tomato"), lwd = 2)

# Plot 2: IPW augmentation terms
hist(abs(ipw_aug), breaks = 50, col = "steelblue", border = "white",
     main = "IPW augmentation terms",
     xlab = expression(group("|", W/hat(e)(L) - (1-W)/(1-hat(e)(L)), "|")))

# Plot 3: EIF distribution
hist(eif, breaks = 50, col = "steelblue", border = "white",
     main = "Efficient influence function for sigma²",
     xlab = "EIF value")

par(mfrow = c(1, 1))

# ============================================================
# Question 4: CATE conditional on income only
# τ(inc) = E[Y¹ - Y⁰ | inc]
#
# Strategy: R-learner (orthogonal/partially linear learner)
#   - Nuisances m̂(L) = E[Y|L] and ê(L) = P(W=1|L) already cross-fitted over ALL covariates in Q1
#       -> full confounding adjustment is preserved
#   - Second stage regresses pseudo-outcome on income ONLY
#       -> clean 1-D curve with valid CIs
# ============================================================

# Step 0: Trim propensities (reuse W_hat already trimmed in Q1)
# W_hat was trimmed to [0.01, 0.99] in Q1; confirm here for safety
eps <- 0.01
W_hat <- pmin(pmax(W_hat, eps), 1 - eps)

# Step 1: Cross-fitted R-learner pseudo-outcomes
# ψ_i = (Y_i - m̂(L_i)) / (W_i - ê(L_i))
# w_i = (W_i - ê(L_i))²
#
# Both nuisances are already cross-fitted from Q1 (Y_hat, W_hat),
# so pseudo-outcomes are honest (no own-observation leakage).

resid_Y <- Y - Y_hat # Ỹ_i = Y_i - m̂(L_i)
resid_W <- W - W_hat # W̃_i = W_i - ê(L_i)

pseudo_outcomes <- resid_Y / resid_W
weights <- resid_W^2

# Diagnostic: check for extreme pseudo-outcomes
cat(sprintf("Pseudo-outcomes | Min: %.0f | Max: %.0f | SD: %.0f\n",
            min(pseudo_outcomes), max(pseudo_outcomes), sd(pseudo_outcomes)))

# Trim extreme pseudo-outcomes (Huber-style; protects second stage)
trim_lo <- quantile(pseudo_outcomes, 0.01)
trim_hi <- quantile(pseudo_outcomes, 0.99)
n_trimmed <- sum(pseudo_outcomes < trim_lo | pseudo_outcomes > trim_hi)
cat(sprintf("Trimmed %d pseudo-outcomes (%.1f%%) to [%.0f, %.0f]\n",
            n_trimmed, 100 * n_trimmed / N, trim_lo, trim_hi))

pseudo_outcomes_trim <- pmin(pmax(pseudo_outcomes, trim_lo), trim_hi)

# Step 2a: Second stage — natural cubic spline (gives honest CIs)
# Regress ψ̃ on income with weights w = W̃²
df_stage2 <- data.frame(
  inc    = X$inc,
  psi    = pseudo_outcomes_trim,
  weight = weights)

# df balances flexibility vs. variance
fit_spline <- lm(psi ~ ns(inc, df = 7),
                 data    = df_stage2,
                 weights = weight)

# Prediction on a fine income grid for plotting
inc_grid <- data.frame(
  inc = seq(quantile(X$inc, 0.02),
            quantile(X$inc, 0.98),
            length.out = 500))

pred_spline <- predict(fit_spline,
                       newdata  = inc_grid,
                       interval = "confidence",
                       level    = 0.95)

curve_df <- data.frame(
  inc = inc_grid$inc,
  tau = pred_spline[, "fit"],
  lo  = pred_spline[, "lwr"],
  hi  = pred_spline[, "upr"])

# Step 2b: Second stage — SuperLearner (flexible, no analytic CIs)
sl_stage2 <- SuperLearner(
  Y          = pseudo_outcomes_trim,
  X          = data.frame(inc = X$inc),   # income ONLY
  obsWeights = weights,
  SL.library = c("SL.gam", "SL.earth", "SL.glm"),
  family     = gaussian(),
  method     = "method.NNLS",
  cvControl  = list(V = 5)
)

curve_df$tau_sl <- predict(sl_stage2, newdata = inc_grid)$pred

# Step 3: Summary at selected income quantiles
inc_pts  <- quantile(X$inc, c(.10, .25, .50, .75, .90))
pred_pts <- predict(fit_spline,
                    newdata  = data.frame(inc = inc_pts),
                    interval = "confidence",
                    level    = 0.95)

cat("\n══ Q4. tau(inc) at selected income quantiles ══════════════════════════════\n")
cat(sprintf("%-12s  %10s   %22s\n", "Income pct", "tau_hat(inc) ($)", "95% CI"))
cat(strrep("─", 50), "\n")
for (i in seq_along(inc_pts)) {
  cat(sprintf("%-12s  %10.0f   ($%7.0f – $%7.0f)\n",
              names(inc_pts)[i],
              pred_pts[i, "fit"],
              pred_pts[i, "lwr"],
              pred_pts[i, "upr"]))
}
cat(strrep("─", 50), "\n")

# Step 4: Plot
ggplot(curve_df, aes(x = inc)) +
  # Spline fit + CI ribbon (primary)
  geom_ribbon(aes(ymin = lo, ymax = hi),
              fill = "steelblue", alpha = 0.25) +
  geom_line(aes(y = tau, colour = "Spline (95% CI)"),
            linewidth = 1.1) +
  # SuperLearner fit (secondary)
  geom_line(aes(y = tau_sl, colour = "SuperLearner"),
            linewidth = 0.9, linetype = "dashed") +
  # Reference lines
  geom_hline(yintercept = ate["estimate"],
             colour = "tomato", linetype = "dashed", linewidth = 0.8) +
  geom_hline(yintercept = 0,
             colour = "grey50", linetype = "dotted") +
  annotate("text",
           x = quantile(X$inc, 0.02),
           y = ate["estimate"],
           label = sprintf("Overall ATE = $%.0f", ate["estimate"]),
           colour = "tomato", size = 3.2, vjust = -0.5, hjust = 0) +
  scale_colour_manual(
    values = c("Spline (95% CI)" = "steelblue",
               "SuperLearner" = "darkgreen")
  ) +
  scale_x_continuous(labels = scales::dollar_format()) +
  scale_y_continuous(labels = scales::dollar_format()) +
  labs(
    title    = "Q4. Effect of 401(k) eligibility on net financial assets by income",
    subtitle = paste("R-learner | nuisances from all covariates (Q1) |",
                     "second stage on income only"),
    x      = "Household income (USD)",
    y      = expression(hat(tau)(inc)),
    colour = NULL
  ) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "top",
        panel.grid.minor = element_blank())

