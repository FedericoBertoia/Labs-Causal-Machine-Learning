# Project members: 
# Matteo Allegrini
# Daniel Kirste



set.seed(2026)


# =============
# Question 1(a)
# =============


library(hdm)
library(grf)
library(dplyr)
library(ggplot2)
library(tidyr)

data(pension)

# exploratory checks
str(pension)
names(pension)
summary(pension)

# Build the analysis dataset
dat <- pension %>%
  transmute(
    Y = net_tfa,        # net financial assets
    W = e401,           # eligibility indicator
    age = age,          # age
    inc = inc,          # income
    fsize = fsize,      # family size
    educ = educ,        # education (in years)
    marr = marr,        # married indicator
    twoearn = twoearn,  # two earner indicator
    db = db,            # defined benefit pension indicator
    pira = pira,        # IRA indicator
    hown = hown         # home ownership indicator
  ) %>%
  na.omit()

# Covariate matrix
X <- dat %>%
  select(age, inc, fsize, educ, marr, twoearn, db, pira, hown) %>%
  as.matrix()

# Outcome and treatment vectors
Y <- dat$Y
W <- dat$W

# Optional quick checks
summary(Y)
mean(W)


# -------------------------
# Full-sample causal forest
# -------------------------
# This forest is used for:
# - the model diagnostics
# - the global ATE summary


cf_full <- causal_forest(
  X = X,
  Y = Y,
  W = W,
  num.trees = 4000,
  honesty = TRUE,
  tune.parameters = "all",
  seed = 2026
)

# CATE predictions from the full forest
dat$tau_hat <- predict(cf_full)$predictions

# -------------------------
# Diagnostics for the full forest
# -------------------------

# Estimated propensity scores from the forest
dat$what_hat <- cf_full$W.hat

# Overlap summary
summary(dat$what_hat)


# Overlap plot
hist(dat$what_hat,
     breaks = 20,
     main = "Estimated propensity scores",
     xlab = "Estimated P(W = 1 | X)")


# Calibration test
cal_test <- test_calibration(cf_full)
print(cal_test)


# Global ATE from the full forest
ate_full <- average_treatment_effect(cf_full)
ate_est <- unname(ate_full["estimate"])
ate_se  <- unname(ate_full["std.err"])
ate_ci  <- c(
  ate_est - 1.96 * ate_se,
  ate_est + 1.96 * ate_se
)

ate_results <- data.frame(
  estimate = ate_est,
  std_error = ate_se,
  ci_lower = ate_ci[1],
  ci_upper = ate_ci[2]
)

print(ate_results)


# 10-fold cross-fitted CATE predictions: 

# With this code we generate cate predictions for all our observations using 10-fold crossfitting
K = 10
n = nrow(X)

fold_id = sample(rep(1:K, length.out = n))  # fold_id is a vector of length n in which every element in integer from 1 to K
tau_hat_cf = rep(NA_real_, n)

for (k in 1:K) {
  test_idx  <- which(fold_id == k)
  train_idx <- setdiff(seq_len(n), test_idx) # get the indexes of the observations that are not in group k (and thus are used in the training)
  
  cf_k <- causal_forest(
    X = X[train_idx, , drop = FALSE],
    Y = Y[train_idx],
    W = W[train_idx],
    num.trees = 4000,
    honesty = TRUE,
    tune.parameters = "all",
    seed = 2026 + k
  )
  
  # Predictions of the causal forest for the observation in the group k (not used for training)
  tau_hat_cf[test_idx] <- predict(cf_k, newdata = X[test_idx, , drop = FALSE])$predictions
}

dat$tau_hat_cf = tau_hat_cf


# Distribution plots for cross-fitted CATEs:

# Histogram of CATE counts
ggplot(dat, aes(x = tau_hat_cf)) +
  geom_histogram(bins = 50) +
  labs(
    #title = "Distribution of cross-fitted CATE predictions",
    x = "Cross-fitted predicted CATE",
    y = "Count"
  ) +
  theme_minimal()

# Density of CATE counts
ggplot(dat, aes(x = tau_hat_cf)) +
  geom_density(fill = "grey80") +
  labs(
    title = "Density of cross-fitted CATE predictions",
    x = "Cross-fitted predicted CATE",
    y = "Density"
  ) +
  theme_minimal()


# Boxplots by binary covariates (combined in one figure)
binary_plot_data <- dat %>%
  select(tau_hat_cf, marr, pira, hown, db, twoearn) %>%
  pivot_longer(
    cols = c(marr, pira, hown, db, twoearn),
    names_to = "variable",
    values_to = "value"
  ) %>%
  mutate(
    variable = recode(
      variable,
      marr = "Married",
      pira = "IRA participation",
      hown = "Home ownership",
      db = "Defined-benefit pension",
      twoearn = "Two-earner household"
    ),
    value = factor(value)
  )

ggplot(binary_plot_data, aes(x = value, y = tau_hat_cf)) +
  geom_boxplot() +
  facet_wrap(~ variable, scales = "free_x") +
  labs(
    #title = "Cross-fitted CATEs by binary covariates",
    x = NULL,
    y = "Cross-fitted predicted CATE"
  ) +
  theme_minimal()



# Average CATE by deciles of continuous covariates

# Income
plot_income <- dat %>%
  mutate(group = ntile(inc, 10)) %>%
  group_by(group) %>%
  summarise(
    x_mean = mean(inc),
    cate_mean = mean(tau_hat_cf),
    variable = "Income",
    .groups = "drop"
  )

# Age
plot_age <- dat %>%
  mutate(group = ntile(age, 10)) %>%
  group_by(group) %>%
  summarise(
    x_mean = mean(age),
    cate_mean = mean(tau_hat_cf),
    variable = "Age",
    .groups = "drop"
  )

# Education
plot_educ <- dat %>%
  mutate(group = ntile(educ, 10)) %>%
  group_by(group) %>%
  summarise(
    x_mean = mean(educ),
    cate_mean = mean(tau_hat_cf),
    variable = "Education",
    .groups = "drop"
  )


# Family size
plot_fsize <- dat %>%
  mutate(group = ntile(fsize, 10)) %>%
  group_by(group) %>%
  summarise(
    x_mean = mean(fsize),
    cate_mean = mean(tau_hat_cf),
    variable = "Family size",
    .groups = "drop"
  )

continuous_plot_data <- bind_rows(plot_income, plot_age)

ggplot(continuous_plot_data, aes(x = x_mean, y = cate_mean)) +
  geom_line() +
  geom_point() +
  facet_wrap(~ variable, scales = "free_x") +
  labs(
    #title = "Average cross-fitted CATE by deciles of continuous covariates",
    x = "Mean value within decile",
    y = "Average cross-fitted CATE"
  ) +
  theme_minimal()


continuous_plot_data <- bind_rows(plot_educ, plot_fsize)

ggplot(continuous_plot_data, aes(x = x_mean, y = cate_mean)) +
  geom_line() +
  geom_point() +
  facet_wrap(~ variable, scales = "free_x") +
  labs(
    #title = "Average cross-fitted CATE by deciles of continuous covariates",
    x = "Mean value within decile",
    y = "Average cross-fitted CATE"
  ) +
  theme_minimal()




# ============
# Question 2
# ============

library(grf)
library(dplyr)
library(ggplot2)


# First we create the 4 subgroups using the cross-fitted CATEs
dat_q2 <- dat %>%
  mutate(
    pred_cate_cf = tau_hat_cf,
    subgroup_id = ntile(pred_cate_cf, 4),
    subgroup = factor(
      subgroup_id,
      levels = 1:4,
      labels = c(
        "Q1",
        "Q2",
        "Q3",
        "Q4"
      )
    )
  )

# each group should contain one quarter of the sample (more or less)
table(dat_q2$subgroup)
dim(X)[1]/4


# Now we estimate the average treatment effect in each subgroup using the function average_treatment_effect() from grf
estimate_subgroup_ate = function(group_label, data, forest) {
  
  idx <- which(data$subgroup == group_label) # get the indexes of the individuals in the group = group_label
  
  ate_g <- average_treatment_effect(forest, subset = idx) # get the average treatment effect for the selected group
  
  # store values
  ate_hat <- unname(ate_g["estimate"])
  se_hat  <- unname(ate_g["std.err"])
  
  data.frame(
    subgroup = group_label,
    n = length(idx),
    
    # we also add mean, min and max for more context
    mean_pred_cate = mean(data$pred_cate_cf[idx]),  
    min_pred_cate  = min(data$pred_cate_cf[idx]),
    max_pred_cate  = max(data$pred_cate_cf[idx]),
    
    ate_hat = ate_hat,
    std_error = se_hat,
    ci_lower = ate_hat - 1.96 * se_hat,
    ci_upper = ate_hat + 1.96 * se_hat
  )
}

subgroup_levels <- levels(dat_q2$subgroup)

q2_results <- lapply(subgroup_levels, estimate_subgroup_ate, data = dat_q2, forest = cf_full) %>%
  bind_rows()

print(q2_results)

# ---------------------------------------------------------
# 3. Cleaner table for the report
# ---------------------------------------------------------
q2_table <- q2_results %>%
  mutate(
    mean_pred_cate = round(mean_pred_cate, 2),
    min_pred_cate  = round(min_pred_cate, 2),
    max_pred_cate  = round(max_pred_cate, 2),
    ate_hat        = round(ate_hat, 2),
    std_error      = round(std_error, 2),
    ci_lower       = round(ci_lower, 2),
    ci_upper       = round(ci_upper, 2)
  )

print(q2_table)

# ---------------------------------------------------------
# 4. Optional plot: subgroup average effects with 95% CI
# ---------------------------------------------------------
fig_q2 <- ggplot(q2_results, aes(x = subgroup, y = ate_hat)) +
  geom_point(size = 2) +
  geom_errorbar(aes(ymin = ci_lower, ymax = ci_upper), width = 0.15) +
  labs(
    #title = "Average effect of 401(k) eligibility by CATE-based subgroup",
    x = NULL,
    y = "Estimated average treatment effect"
  ) +
  theme_minimal()

print(fig_q2)



# Now we shortly analyze the individuals represented by the four subgroups that we found.
profile_q2 <- dat_q2 %>%
  group_by(subgroup) %>%
  summarise(
    n = n(),
    age_mean = mean(age),
    inc_mean = mean(inc),
    educ_mean = mean(educ),
    fsize_mean = mean(fsize),
    marr_rate = mean(marr),
    twoearn_rate = mean(twoearn),
    db_rate = mean(db),
    pira_rate = mean(pira),
    hown_rate = mean(hown),
    .groups = "drop"
  )

print(profile_q2)







# ============
# Question 3
# ============

# We want to estimate:
# sigma^2 = Var{ E[Y(1) - Y(0) | L] } = Var{ tau(L) }

# to do that, we use the efficient influence function (EIF) which requires the following quantities: 
# - CATE: E[Y(1) - Y(0) | L]
# - ATE:  E[Y(1) - Y(0)]
# - propensity score: e(L) = P(A = 1 | L)
# - outcome mean given covariates: m(L) = E[Y | L]
# - outcome mean given treatment and covariates: mu(A, L) = E[Y | A, L]


# We can reuse the cross-fitted CATE from Question 1
cate_hat <- dat$tau_hat_cf


# estimate of the ATE 
ate_q3 <- average_treatment_effect(cf_full)
ate_hat <- unname(ate_q3["estimate"])


# Now we estimate:
#    e(L) = P(A = 1 | L) 
#    m(L) = E[Y | L]
# by fitting regression forests with K-fold cross-fitting
K_q3 <- 10
n <- nrow(X)
fold_id <- sample(rep(1:K_q3, length.out = n))

prop_scores <- rep(NA_real_, n)
m_hat <- rep(NA_real_, n)

for (k in 1:K_q3) {
  test_idx  <- which(fold_id == k)
  train_idx <- setdiff(seq_len(n), test_idx)
  
  # Cross-fitted propensity score e(L)
  forest_e <- regression_forest(
    X = X[train_idx, , drop = FALSE],
    Y = W[train_idx],
    tune.parameters = "all",
    seed = 3000 + k
  )
  
  prop_scores[test_idx] <- predict(
    forest_e,
    newdata = X[test_idx, , drop = FALSE]
  )$predictions
  
  # Cross-fitted marginal outcome mean m(L)
  forest_m <- regression_forest(
    X = X[train_idx, , drop = FALSE],
    Y = Y[train_idx],
    tune.parameters = "all",
    seed = 4000 + k
  )
  
  m_hat[test_idx] <- predict(
    forest_m,
    newdata = X[test_idx, , drop = FALSE]
  )$predictions
}


summary(prop_scores)
summary(m_hat)


# Now we construct:
# - mu_0(L) = E[Y | A = 0, L]
# - mu_1(L) = E[Y | A = 1, L]
# - mu_A(L) = E[Y | A, L], evaluated at the observed treatment A
#
# using the identities:
# mu_0(L) = m(L) - e(L) * tau(L)
# mu_1(L) = m(L) + (1 - e(L)) * tau(L)

mu0_hat <- m_hat - prop_scores * cate_hat
mu1_hat <- m_hat + (1 - prop_scores) * cate_hat
mu_A_hat <- ifelse(W == 1, mu1_hat, mu0_hat)


# We clip the propencity scores so that they are in the interval [0.001, 0.999] to stabilize the inverse-probability term
eps <- 1e-3
e_clip <- pmin(pmax(prop_scores, eps), 1 - eps)


# Now we compute the inverse-probability term
ipw_term <- W / e_clip - (1 - W) / (1 - e_clip)


# Now we compute the estimated score using the EIF formula
score_sigma2 <- (cate_hat - ate_hat)^2 + 2 * (cate_hat - ate_hat) * ipw_term * (Y - mu_A_hat)

# This is our estimate of the variance of our conditional average treatment effects
sigma2_hat <- mean(score_sigma2)

sqrt(sigma2_hat) # std error (in dollars)

# Centered estimated influence function
phi_hat <- score_sigma2 - sigma2_hat



# Standard deviation of the estimated variance
sigma2_se <- sd(phi_hat) / sqrt(n)

# 95% confidence interval
sigma2_ci <- c(
  sigma2_hat - 1.96 * sigma2_se,
  sigma2_hat + 1.96 * sigma2_se
)

q3_results <- data.frame(
  estimate = sigma2_hat,
  std_error = sigma2_se,
  ci_lower = sigma2_ci[1],
  ci_upper = sigma2_ci[2]
)

print(q3_results)



# Quality checks

cat("Range of clipped propensity scores:", round(range(e_clip), 3), "\n") # prints min and max prop scores
cat("Max |centered IF|:", round(max(abs(phi_hat)), 0), "\n")              # max absolute value of phi_hat
cat("Fraction with |IPW term| > 10:", mean(abs(ipw_term) > 10), "\n")     # % of observations for which IPW term is big in module

# distribution of phi_hat
hist(phi_hat,
     breaks = 10000,
     main = "Centered influence function for sigma^2",
     xlab = "phi_hat",
     col = "steelblue")








# ============
# Question 4
# ============

# For this question we want to estimate the treatment effect of 401(k) eligibility on net financial assets
# conditional only on income, while still controlling for the full set of covariates.


# To do that, we use an orthogonal learner:
# - we estimate e(L) = P(A = 1 | L) and m(L) = E[Y | L] using K-fold cross-fitting
# - we residualize both outcome and treatment
# - we then estimate the treatment effect as a smooth function of income only


# First we estimate:
# e(L) = P(A = 1 | L)
# m(L) = E[Y | L]
# by fitting regression forests with K-fold cross-fitting
K_q4 <- 10
n_q4 <- nrow(X)
fold_id_q4 <- sample(rep(1:K_q4, length.out = n_q4))

e_hat_q4 <- rep(NA_real_, n_q4)
m_hat_q4 <- rep(NA_real_, n_q4)

for (k in 1:K_q4) {
  test_idx  <- which(fold_id_q4 == k)
  train_idx <- setdiff(seq_len(n_q4), test_idx)
  
  # Cross-fitted propensity score e(L)
  forest_e <- regression_forest(
    X = X[train_idx, , drop = FALSE],
    Y = W[train_idx],
    tune.parameters = "all",
    seed = 3000 + k
  )
  
  e_hat_q4[test_idx] <- predict(
    forest_e,
    newdata = X[test_idx, , drop = FALSE]
  )$predictions
  
  # Cross-fitted marginal outcome mean m(L)
  forest_m <- regression_forest(
    X = X[train_idx, , drop = FALSE],
    Y = Y[train_idx],
    tune.parameters = "all",
    seed = 4000 + k
  )
  
  m_hat_q4[test_idx] <- predict(
    forest_m,
    newdata = X[test_idx, , drop = FALSE]
  )$predictions
}


summary(e_hat_q4)
summary(m_hat_q4)


# Now we residualize the outcome and the treatment
Y_tilde <- Y - m_hat_q4
A_tilde <- W - e_hat_q4

income <- dat$inc


# Now we estimate the treatment effect as a function of income only
# using a local constant kernel smoother

income_grid <- seq(
  quantile(income, 0.02),
  quantile(income, 0.98),
  length.out = 200
)


# rule-of-thumb bandwidth
h_bw <- 1.06 * sd(income) * n_q4^(-1 / 5)

cat(sprintf("Bandwidth for kernel smoother: %.0f\n", h_bw))


kernel_smooth_cate <- function(v, income, Y_tilde, A_tilde, h) {
  # Gaussian kernel weights centered at income value v
  w <- dnorm((income - v) / h)
  
  numerator <- sum(w * A_tilde * Y_tilde)
  denominator <- sum(w * A_tilde^2)
  
  if (abs(denominator) < 1e-8) return(NA_real_)
  
  numerator / denominator
}


# Estimated treatment effect as a function of income
tau_income_hat <- sapply(
  income_grid,
  kernel_smooth_cate,
  income = income,
  Y_tilde = Y_tilde,
  A_tilde = A_tilde,
  h = h_bw
)


# Now we compute bootstrap standard errors pointwise along the income grid


B <- 200
boot_mat <- matrix(NA_real_, nrow = B, ncol = length(income_grid))

for (b in seq_len(B)) {
  idx <- sample(n_q4, n_q4, replace = TRUE)
  
  boot_mat[b, ] <- sapply(
    income_grid,
    kernel_smooth_cate,
    income = income[idx],
    Y_tilde = Y_tilde[idx],
    A_tilde = A_tilde[idx],
    h = h_bw
  )
}

tau_income_se <- apply(boot_mat, 2, sd, na.rm = TRUE)


# 95% pointwise confidence intervals
q4_results <- data.frame(
  income = income_grid,
  tau_hat = tau_income_hat,
  std_error = tau_income_se,
  ci_lower = tau_income_hat - 1.96 * tau_income_se,
  ci_upper = tau_income_hat + 1.96 * tau_income_se
)

print(head(q4_results))


# Visualization
fig_q4 <- ggplot(q4_results, aes(x = income, y = tau_hat)) +
  geom_ribbon(
    aes(ymin = ci_lower, ymax = ci_upper),
    fill = "lightblue",
    alpha = 0.6
  ) +
  geom_line(color = "darkblue", linewidth = 0.8) +
  labs(
    x = "Income",
    y = "Estimated average treatment effect",
    title = ""
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16),
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12),
    aspect.ratio = 0.55
  )

print(fig_q4)
