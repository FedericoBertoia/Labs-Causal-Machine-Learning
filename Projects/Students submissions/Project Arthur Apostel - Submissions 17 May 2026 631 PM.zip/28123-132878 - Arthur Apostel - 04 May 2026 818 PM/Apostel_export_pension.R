####################################
# EXPORT PENSION DATA
# This file exports the hdm pension data to csv for use in python
# Author: Arthur Apostel
# Date: 28/04/2026
####################################

####################################
# 1. PRELIMINARIES
####################################

print('Exporting pension data')

# install hdm (only once)
# install.packages("hdm", repos = "https://cloud.r-project.org")

library(hdm)

####################################
# 2. EXPORT
####################################

data(pension)

out_path <- "C:/Users/aapostel/OneDrive - UGent/Lessen/Causal machine learning/project/pension.csv"
write.csv(pension, out_path, row.names = FALSE)
