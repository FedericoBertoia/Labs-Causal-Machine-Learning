############################################
# CAUSAL MACHINE LEARNING PROJECT
# Arthur Apostel (solo group)
############################################

# import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# machine learning libraries
from sklearn.ensemble import (
    StackingRegressor, StackingClassifier,
    RandomForestRegressor, RandomForestClassifier,
    GradientBoostingRegressor, GradientBoostingClassifier,
)
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import SplineTransformer
from econml.dml import CausalForestDML


############################################
# INITIALISATION
############################################

# set seed
seed = 42
np.random.seed(seed)

# plot style
plt.style.use('seaborn-v0_8-darkgrid')

# set paths
main_path = 'C:/Users/aapostel/OneDrive - UGent/Lessen/Causal machine learning/project'
figures_path = main_path + '/figures'

# change pandas display setting
pd.set_option('display.max_columns', None) # show all columns of df
# pd.set_option('display.max_rows', None) # show all rows

############################################
# DATA LOADING AND EXPLORATORY DATA ANALYSIS
############################################

## LOAD VARIABLES
df = pd.read_csv(main_path + '/pension.csv') # previously exported from R script

covariates = ['age', 'inc', 'fsize', 'educ', 'marr', 'twoearn', 'db', 'pira', 'hown']
treatment = 'e401'
outcome = 'net_tfa'

# some data checks
df.shape # 9915 obs, as expected
df.describe() # nothing looks weird
df[treatment].unique() # treatment only consists of 0 and 1

# create input arrays
y = df[outcome].to_numpy()
a = df[treatment].to_numpy()
x = df[covariates].to_numpy()

## EXPLORATORY DATA ANALYSIS

# outcome distribution (looks plausible, large outliers)
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(y, bins=80)
ax.set_xlabel('net_tfa')
ax.set_ylabel('frequency')
ax.set_title('distribution')
fig.savefig(figures_path + '/outcome_distribution.png', bbox_inches='tight') 

# covariate distributions
continuous = ['age', 'inc', 'fsize', 'educ']
binary = ['marr', 'twoearn', 'db', 'pira', 'hown']
fig, axes = plt.subplots(3, 3, figsize=(11, 9))
for ax, var in zip(axes.flat, covariates):
    if var in continuous:
        ax.hist(df[var], bins=30)
        ax.set_title(var)
    else:
        counts = df[var].value_counts().sort_index()
        ax.bar(counts.index, counts.values)
        ax.set_title(f'{var} (binary)')
    ax.set_ylabel('frequency')
fig.suptitle('covariate distributions')
fig.savefig(figures_path + '/covariate_distributions.png', bbox_inches='tight')

############################################
# SUPERLEARNERS FOR NUISANCE FUNCTION ESTIMATION
############################################

# define superlearners to estimate nuisance functions
def build_model_y():
    return StackingRegressor(
        estimators=[
            ('ols', LinearRegression()),
            ('rf',  RandomForestRegressor(n_estimators=500, random_state=seed, n_jobs=-1)),
            ('gb',  GradientBoostingRegressor(random_state=seed)),
        ],
        final_estimator=LinearRegression(positive=True, fit_intercept=False),
        cv=5, n_jobs=-1,
    )

def build_model_t():
    return StackingClassifier(
        estimators=[
            ('logit', LogisticRegression(penalty=None, max_iter=5000, random_state=seed)),
            ('rf',    RandomForestClassifier(n_estimators=500, random_state=seed, n_jobs=-1)),
            ('gb',    GradientBoostingClassifier(random_state=seed)),
        ],
        final_estimator=LogisticRegression(max_iter=5000),
        cv=5, n_jobs=-1,
    )

############################################
# TASK 1: CAUSAL FOREST
############################################

# fit causal forest
cf = CausalForestDML(
    model_y=build_model_y(),
    model_t=build_model_t(),
    discrete_treatment=True,
    n_estimators=2000,
    cv=5,
    random_state=seed,
)
cf.fit(Y=y, T=a, X=x)

# estimate psi_hat (conditional ATE for each individual)
psi_hat = cf.effect(x)

# results (Q1A)

# graph: distribution of estimated CATEs
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(psi_hat, bins=60)
ax.set_xlabel(r'$\hat{\psi}(L)$')
ax.set_ylabel('frequency')
ax.set_title(r'distribution of estimated CATEs $\hat{\psi}(L)$')
ax.legend()
fig.savefig(figures_path + '/cate_distribution.png', bbox_inches='tight')


############################################
# SHARED CROSS-FITTED NUISANCES (used in tasks 2 and 3)
############################################

# treated and non-treated outcome and propensity score regressions, all 5-fold cross-fitted
# same superlearner libraries as task 1
kf = KFold(n_splits=5, shuffle=True, random_state=seed)

Q1_hat = np.zeros(len(y))
Q0_hat = np.zeros(len(y))
pi_hat  = np.zeros(len(y))

for fold, (train_idx, test_idx) in enumerate(kf.split(x), start=1):
    
    x_tr, x_te = x[train_idx], x[test_idx]
    y_tr, a_tr = y[train_idx], a[train_idx]

    # propensity score
    m_t = build_model_t()
    m_t.fit(x_tr, a_tr)
    pi_hat[test_idx] = m_t.predict_proba(x_te)[:, 1]

    # outcome among treated
    m_y1 = build_model_y()
    m_y1.fit(x_tr[a_tr == 1], y_tr[a_tr == 1])
    Q1_hat[test_idx] = m_y1.predict(x_te)

    # outcome among controls
    m_y0 = build_model_y()
    m_y0.fit(x_tr[a_tr == 0], y_tr[a_tr == 0])
    Q0_hat[test_idx] = m_y0.predict(x_te)

# aipw estimator for the ATE
psi_aipw = (a / pi_hat * (y - Q1_hat)
            - (1 - a) / (1 - pi_hat) * (y - Q0_hat)
            + Q1_hat - Q0_hat)

# check overlap of propensity score
fig, ax = plt.subplots(figsize=(7, 5))
pi_by_treat = [pi_hat[a == 0], pi_hat[a == 1]]
ax.boxplot(pi_by_treat, positions=[0, 1], widths=0.4, showfliers=False)
rng = np.random.default_rng(seed)
for k, group in enumerate(pi_by_treat):
    jitter = rng.uniform(-0.15, 0.15, size=len(group))
    ax.scatter(np.full(len(group), k) + jitter, group,
               alpha=0.15, s=8, color='black')
ax.set_xticks([0, 1])
ax.set_xticklabels(['A=0 (ineligible)', 'A=1 (eligible)'])
ax.set_ylabel(r'$\hat{\pi}(L)$')
ax.set_title('propensity score overlap by treatment')
fig.savefig(figures_path + '/propensity_overlap.png', bbox_inches='tight')
print(f'propensity score range (A=0): [{pi_hat[a == 0].min():.3f}, {pi_hat[a == 0].max():.3f}]')
print(f'propensity score range (A=1): [{pi_hat[a == 1].min():.3f}, {pi_hat[a == 1].max():.3f}]')

############################################
# TASK 2: SUBGROUP ATE
############################################

# 4 quartiles of the cf predictions psi_hat
q_labels = pd.qcut(psi_hat, 4, labels=False)
quartile_names = ['Q1 (lowest psi)', 'Q2', 'Q3', 'Q4 (highest psi)']

# subgroup AIPW ATE + 95% CI per quartile
subgroup_results = []
for k in range(4):
    mask = q_labels == k
    n_k = int(mask.sum())
    psi_k = psi_hat[mask]
    aipw_k = psi_aipw[mask]
    pi_k = pi_hat[mask]

    ate_aipw_k = aipw_k.mean()
    eif_ate_aipw_k = aipw_k - ate_aipw_k
    se_ate_aipw_k = eif_ate_aipw_k.std(ddof=1) / np.sqrt(n_k)
    ate_aipw_k_ci_low  = ate_aipw_k - 1.96 * se_ate_aipw_k
    ate_aipw_k_ci_high = ate_aipw_k + 1.96 * se_ate_aipw_k

    print(f'{quartile_names[k]}: n={n_k}, '
          f'psi_hat range=[{psi_k.min():.0f}, {psi_k.max():.0f}], '
          f'mean psi_hat={psi_k.mean():.0f}, '
          f'AIPW ATE={ate_aipw_k:.0f} '
          f'[95% CI {ate_aipw_k_ci_low:.0f}, {ate_aipw_k_ci_high:.0f}], '
          f'pi range=[{pi_k.min():.3f}, {pi_k.max():.3f}]')
    subgroup_results.append(
        (quartile_names[k], ate_aipw_k, ate_aipw_k_ci_low, ate_aipw_k_ci_high, psi_k.mean()))

# top influence-function values for the overall AIPW ATE (extreme i diagnostic)
ate_aipw = psi_aipw.mean()
eif_ate_aipw = psi_aipw - ate_aipw
top_idx = np.argsort(np.abs(eif_ate_aipw))[-10:][::-1]
for i in top_idx:
    print(f'i={i}: psi_aipw={psi_aipw[i]:.0f}, pi={pi_hat[i]:.3f}, '
          f'A={int(a[i])}, Y={y[i]:.0f}')
    
# graph: distribution of the eif
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(eif_ate_aipw, bins=80)
ax.axvline(0, color='black', lw=0.7)
ax.set_xlabel('ATE')
ax.set_ylabel('frequency')
ax.set_title('distribution of the EIF for AIPW ATE')
fig.savefig(figures_path + '/aipw_eif_distribution.png', bbox_inches='tight')

# graph: subgroup ATEs with 95% CIs
fig, ax = plt.subplots(figsize=(8, 5))
positions = np.arange(4)
ate_arr = np.array([r[1] for r in subgroup_results])
lo_arr  = np.array([r[2] for r in subgroup_results])
hi_arr  = np.array([r[3] for r in subgroup_results])
psi_means = np.array([r[4] for r in subgroup_results])

ax.errorbar(ate_arr, positions,
            xerr=[ate_arr - lo_arr, hi_arr - ate_arr],
            fmt='o', capsize=4, color='black', label='AIPW estimate')
ax.axvline(0, color='black', lw=0.5)
ax.set_yticks(positions)
ax.set_yticklabels(quartile_names)
ax.set_xlabel('subgroup ATE on net financial assets (USD)')
ax.set_title(r'AIPW subgroup ATEs by quartile of $\hat{\psi}(L)$')
ax.legend()
fig.savefig(figures_path + '/subgroup_ates.png', bbox_inches='tight')


############################################
# TASK 3: VARIANCE OF THE CATE
############################################

# psi_hat is the cross-fitted causal-forest CATE from task 1
# pi_hat is the shared cross-fitted nuisances above

# model for E[Y|A,L] (based on shared cross-fitted nuisances)
Q_hat = a * Q1_hat + (1 - a) * Q0_hat

n = len(y)
psi_bar = psi_hat.mean()

# the assignment gives the eif of sigma^2 = Var{E[Y^1 - Y^0 | L]} as
#   {psi(L) - E[psi]}^2 - sigma^2
#   + 2 {psi(L) - E[psi]} * (A/P(A=1|L) - (1-A)/P(A=0|L)) * (Y - E[Y|A,L])
# the estimator solves mean(eif) = 0 for sigma^2, which gives sigma^2 as the
# sample mean of the formula with the -sigma^2 term dropped
sigma2_hat = np.mean(
    (psi_hat - psi_bar) ** 2
    + 2 * (psi_hat - psi_bar) * (a / pi_hat - (1 - a) / (1 - pi_hat)) * (y - Q_hat)
)

# eif at sigma^2_hat (for se and CI construction)
eif_sigma2 = (
    (psi_hat - psi_bar) ** 2 - sigma2_hat
    + 2 * (psi_hat - psi_bar) * (a / pi_hat - (1 - a) / (1 - pi_hat)) * (y - Q_hat)
)
se_sigma2 = eif_sigma2.std(ddof=1) / np.sqrt(n)
sigma2_ci_low  = sigma2_hat - 1.96 * se_sigma2
sigma2_ci_high = sigma2_hat + 1.96 * se_sigma2

# output
print(f'sigma^2: {sigma2_hat:.0f}')
print(f'SE of sigma^2: {se_sigma2:.0f}')
print(f'95% CI: [{sigma2_ci_low:.0f}, {sigma2_ci_high:.0f}]')

# sqrt(sigma^2) = sd of CATE across L
sd_cate = np.sqrt(max(sigma2_hat, 0.0))
print(f'sqrt(sigma^2): {sd_cate:.0f}')

# check: eif observations
top_idx = np.argsort(np.abs(eif_sigma2))[-10:][::-1]
print('top 10 EIF observations (sigma^2):')
for i in top_idx:
    print(f'  i={i}: eif_sigma2={eif_sigma2[i]:.0f}, psi_hat={psi_hat[i]:.0f}, '
          f'pi={pi_hat[i]:.3f}, A={int(a[i])}, Y={y[i]:.0f}, Q={Q_hat[i]:.0f}')

# graph: distribution of the eif
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(eif_sigma2, bins=80)
ax.axvline(0, color='black', lw=0.7)
ax.set_xlabel(r'$\hat{\varphi}_i$')
ax.set_ylabel('frequency')
ax.set_title(r'distribution of the EIF for $\sigma^2$')
fig.savefig(figures_path + '/sigma2_eif_distribution.png', bbox_inches='tight')


############################################
# TASK 4: ORTHOGONAL LEARNER FOR INCOME-CONDITIONAL CATE
############################################

# estimand: psi(inc) = E[Y^1 - Y^0 | inc]
# the other 8 covariates stay in the nuisance models for confounding adjustment

# cross-fit E[Y|L]
EY_hat = np.zeros(len(y))
for fold, (train_idx, test_idx) in enumerate(kf.split(x), start=1):
    m = build_model_y()
    m.fit(x[train_idx], y[train_idx])
    EY_hat[test_idx] = m.predict(x[test_idx])

# r-learner pseudo-outcome and weights
# y_pseudo = (Y - E[Y|L]) / (A - E[A|L])
# w_r = (A - E[A|L])^2
y_pseudo = (y - EY_hat) / (a - pi_hat)
w_r = (a - pi_hat) ** 2

# check weight distribution
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(w_r, bins=80)
ax.set_xlabel(r'$w_i = (A_i - \hat{\pi}(L_i))^2$')
ax.set_ylabel('frequency')
ax.set_title('sample-weight distribution')
fig.savefig(figures_path + '/rlearner_weight_distribution.png', bbox_inches='tight')

# psi(inc) via a weighted spline
inc = df[['inc']].to_numpy()
psi_model = Pipeline([
    ('spline', SplineTransformer(n_knots=5, degree=3, knots='quantile', extrapolation='linear')),
    ('linear', LinearRegression()),
])
psi_model.fit(inc, y_pseudo, linear__sample_weight=w_r)

# evaluate over the full observed income range
inc_grid = np.linspace(df['inc'].min(), df['inc'].max(), 200).reshape(-1, 1)
psi_inc = psi_model.predict(inc_grid)

# implied ATE: sample mean of psi_hat(inc) over observed incomes
psi_inc_sample = psi_model.predict(inc)
implied_ate = psi_inc_sample.mean()

# graph: psi(inc) on nominal income
fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(inc_grid.ravel(), psi_inc, lw=2,
        label=r'$\hat{\psi}(\mathrm{inc})$')
ax.axhline(0, color='black', lw=0.6)
ax.set_xlabel('income')
ax.set_ylabel('CATE on net financial assets')
ax.set_title(r'income-conditional CATE $\hat{\psi}(\mathrm{inc})$')
ax.legend(loc='upper left')
fig.savefig(figures_path + '/cate_by_income.png', bbox_inches='tight')

# graph: psi(inc) over income percentiles
percentiles = np.arange(1, 100)
inc_at_percentile = np.percentile(df['inc'], percentiles).reshape(-1, 1)
psi_at_percentile = psi_model.predict(inc_at_percentile)

fig, ax = plt.subplots(figsize=(8, 5))
ax.plot(percentiles, psi_at_percentile, lw=2,
        label=r'$\hat{\psi}(\mathrm{inc})$')
ax.axhline(0, color='black', lw=0.6)
ax.set_xlabel('income percentile')
ax.set_ylabel('CATE on net financial assets')
ax.set_title(r'income-conditional CATE $\hat{\psi}(\mathrm{inc})$ by income percentile')
ax.legend(loc='upper left')
fig.savefig(figures_path + '/cate_by_income_percentile.png', bbox_inches='tight')

