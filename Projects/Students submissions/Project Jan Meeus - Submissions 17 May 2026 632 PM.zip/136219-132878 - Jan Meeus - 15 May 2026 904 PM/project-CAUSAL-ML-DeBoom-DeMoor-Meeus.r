library(hdm)
library(SuperLearner)
library(dplyr)
library(ggplot2)
library(grf)
library(stats)
library(DiagrammeR)
data(pension)


#################################################################################################################################################################################
# Explanatory data analysis
#################################################################################################################################################################################


Data_fr <- as.data.frame(pension)
?pension #For more information about the variables

str(Data_fr)
head(Data_fr,5)

any(is.na(Data_fr)) #There is no missing data


### The outcome: net_tfa

#Histogram of the outcome variable (net financial assets)
hist(Data_fr[["net_tfa"]],
     breaks = 100, 
     main = paste("Histogram of net finacial assest (net_tfa)"), 
     xlab = "net_tfa", 
     col = "lightblue", 
     border = "white")

#Boxpot of outcome and outliers
bp <- boxplot(Data_fr[["net_tfa"]],
              horizontal = TRUE,
              col = "lightblue",
              main = "Boxplot of net_tfa and outlier datapoints")
points(bp$out,
       rep(1, length(bp$out)),
       pch = 1)

### The exposure: e401
barplot(c( sum(Data_fr[["e401"]] == 0), sum(Data_fr[["e401"]] == 1)),
        names.arg = c(0, 1),
        main = paste("Frequency of eligibility for 401k plan (e401)"), 
        xlab = "e401", 
        col = "orange", 
        border = "white")

#The outcome vs exposure:
boxplot(net_tfa ~ e401,
        data = Data_fr,
        names = c(0,1),
        main = "net_tfa by e401",
        ylab = "net_tfa")

### The confounders

#Histogram of the covariates we will use to adjust for confounding
covariates <- c("age","inc","fsize","educ","marr","twoearn","db","pira","hown")

par(mfrow = c(3, 3), cex.main = 1.5,cex.lab = 1.5,cex.axis = 1.3)
for (var in covariates) {
  hist(Data_fr[[var]], 
       main = paste("Histogram of", var), 
       xlab = var, 
       col = "red", 
       border = "white")
}
par(mfrow = c(1, 1))

bp <- boxplot(Data_fr[["inc"]],
              horizontal = TRUE,
              col = "red",
              main = "Boxplot of income and outlier datapoints")
points(bp$out,
       rep(1, length(bp$out)),
       pch = 1)

#Linear association between the continuous covariates and the outcome (unconditional on other variables):
cont_covar <- c("age","inc","fsize","educ")

par(mfrow = c(2, 2), cex.main = 1.5,cex.lab = 1.5,cex.axis = 1.3)
for (var in cont_covar) {
  plot(Data_fr[[var]], Data_fr[["net_tfa"]],
       main = paste("net_tfa vs", var),
       xlab = var,
       ylab = "net_tfa",
       pch = 16,
       col = rgb(0, 0, 0, 0.3))
}
par(mfrow = c(1, 1))


#We fit a simple linear regression on the scaled data
Data_std <- Data_fr
Data_std[c("age","inc","fsize","educ")] <- scale(Data_std[c("age","inc","fsize","educ")])

simple_lin <- lm(net_tfa ~ e401 + age + inc + fsize + educ + marr + twoearn + db + pira + hown,
                 data = Data_std)
summary(simple_lin)

set.seed(100)
Y <- pension$net_tfa
A <- pension$e401
X <- pension[c("age","inc","fsize","educ","marr","twoearn","db","pira","hown")]

######################### 1a #################
# effect of e401 on net_tfa in function of age, inc, fsize, educ, marr, twoearn, db, pira, hown

N <- nrow(X)

n_folds <- 5
fold_id <- sample(rep(1:n_folds, length.out = N))
folds   <- split(seq_len(N), fold_id)

preds <- numeric(N)
sigmas <- numeric(N)

for (k in 1:n_folds) {
  
  test  <- folds[[k]]
  train <- setdiff(seq_len(N), test)
  
  forest <- causal_forest(X=X[train,],Y=Y[train],W=A[train])
  pred <- predict(forest, X[test,], estimate.variance = TRUE)
  
  preds[test] <- pred$predictions
  sigmas[test] <- sqrt(pred$variance.estimates)
}


#histogram of predictions
df <- data.frame(preds = preds,A = as.factor(A))

ggplot(df, aes(x = preds, fill = A)) +
  geom_histogram(position = "identity", alpha = 0.5, bins = 30) +
  labs(title = "Histogram of predictions by e401",
       x = "Predictions",
       y = "Count",
       fill = "e401") +
  theme_minimal()

# Compute confidence intervals
lower <- preds - 1.96 * sigmas
upper <- preds + 1.96 * sigmas
width <- upper - lower

# Data frame
df <- data.frame(
  preds = preds,
  lower = lower,
  upper = upper,
  width = width
)

# Sort by CI width
df <- df[order(df$preds), ]

# x positions
df$id <- seq_len(nrow(df))

# Vertical plot
plot(
  df$id, df$preds,
  ylim = range(c(df$lower, df$upper)),
  pch = 19,
  xlab = "Observation (sorted by CATE)",
  ylab = "CATE",
  main = "95% Confidence Intervals for CATE"
)

# Draw vertical confidence intervals
segments(
  x0 = df$id,
  y0 = df$lower,
  x1 = df$id,
  y1 = df$upper,
  lwd = 2
)

# Optional horizontal reference line
abline(h = 0, lty = 2, col = "gray")


################# 1b ###########

#this way you are no longer seeing the complete effect but only the direct effect
#A could be the PIRA: if you egligeable you would not save in the retirment plan, but
# if you aren't then you would maybe be more likely to save
dag1 <- grViz("
digraph Q1 {
  graph [layout = neato, bgcolor = transparent]
  
  node [shape = plaintext, fontname = 'Helvetica', fontsize = 16]
  
  E401 [pos = '0,0!']
  A [pos = '2,1.5!',shape=box]
  Net_tfa [pos = '4,0!']
  
  edge [arrowhead = vee, arrowsize = 0.7, penwidth = 1.5, color = '#444444']
  E401 -> Net_tfa
  E401 -> A
  A -> Net_tfa
}
")
dag1

#conditioning on a collider opens up a previously blocked path
dag2 <- grViz("
digraph Q1 {
  graph [layout = neato, bgcolor = transparent]
  
  node [shape = plaintext, fontname = 'Helvetica', fontsize = 16]
  
  E401 [pos = '0,0!']
  e401 [pos = '1,0!']
  A [pos = '1.5,1.5!',shape=box]
  B [pos = '3,1.5!']
  Net_tfa [pos = '4.5,0!']
  
  edge [arrowhead = vee, arrowsize = 0.7, penwidth = 1.5, color = '#444444']
  e401 -> Net_tfa
  E401 -> A
  B -> A
  B -> Net_tfa
}
")
dag2

#both these cases never occur with the variables that are given,
#we think that the actual causal diagram looks something like this:
#here X is income along with the other covariates,
#(these other covariates just have an effect on income so it has the same representation)

dag3 <- grViz("
digraph Q1 {
  graph [layout = neato, bgcolor = transparent]
  
  node [shape = plaintext, fontname = 'Helvetica', fontsize = 16]
  
  E401 [pos = '0,0!']
  X [pos = '2,1.5!',shape=box]
  Net_tfa [pos = '4,0!']
  
  edge [arrowhead = vee, arrowsize = 0.7, penwidth = 1.5, color = '#444444']
  E401 -> Net_tfa
  X -> E401
  X -> Net_tfa
}
")
dag3
#it is just important that exchangeability doesn't have an effect on any of the other covariates
#which is the case



#if all variables are pre-treatment -> there is not a single problem

#if there are variables that are post treatment, problems can occur
#then PIRA can be a mediator and then we would be underestimating the the total effect, so mediation analysis should be done in that case


######################### 2 #################
#2 ATE -> AIPW

n<-4
index <- ntile(preds,n=n)

mean_preds <- numeric(n)
mean_sigmas <- numeric(n)

pi_list <- vector("list",n)
psi_list <- vector("list",n)

SL.library <- c("SL.glm", "SL.ranger", "SL.gam", "SL.earth")

for (k in 1:n) {
  Y_sub <- Y[index==k]
  A_sub <- A[index==k]
  X_sub <- X[index==k,]
  
  N_sub <- nrow(X_sub)
  
  n_folds <- 5
  fold_id <- sample(rep(1:n_folds, length.out = N_sub))
  folds   <- split(seq_len(N_sub), fold_id)
  
  Q1 <- numeric(N_sub)
  Q0 <- numeric(N_sub)
  
  for (j in 1:n_folds) {
    
    test  <- folds[[j]]
    train <- setdiff(seq_len(N_sub), test)
    
    sl_Q <- SuperLearner(
      Y          = Y_sub[train],
      X          = data.frame(A = A_sub[train], X_sub[train, ]),
      SL.library = SL.library,
      family     = gaussian(),
      method     = "method.NNLS",
      cvControl  = list(V = 5)
    )
    
    Q1[test] <- predict(sl_Q, newdata = data.frame(A = 1, X_sub[test, ]))$pred
    Q0[test] <- predict(sl_Q, newdata = data.frame(A = 0, X_sub[test, ]))$pred
  }
  
  pi_hat <- numeric(N_sub)
  
  for (j in 1:n_folds) {
    
    test  <- folds[[j]]
    train <- setdiff(seq_len(N_sub), test)
    
    sl_pi <- SuperLearner(
      Y          = A_sub[train],
      X          = X_sub[train, ],
      SL.library = SL.library,
      family     = binomial(),
      method     = "method.NNLS",
      cvControl  = list(V = 5)
    )
    
    pi_hat[test] <- predict(sl_pi, newdata = X_sub[test, ])$pred
  }
  
  aug_1    <-  A_sub      * (Y_sub - Q1) / pi_hat
  aug_0    <- (1 - A_sub) * (Y_sub - Q0) / (1 - pi_hat)
  psi_i    <- (Q1 - Q0) + aug_1 - aug_0
  
  pi_list[[k]] <- pi_hat
  psi_list[[k]] <- psi_i
  
  ate_aipw <- mean(psi_i)
  se_aipw  <- sd(psi_i) / sqrt(N_sub)
  
  mean_preds[k] <- ate_aipw
  mean_sigmas[k] <- se_aipw
  sprintf("Iteration: %d",k)
}

#PROP SCORES
par(mfrow = c(2, 2), oma = c(0, 0, 3, 0))

for (k in 1:n){
  
  lower_q <- quantile(pi_list[[k]], 0.01)
  upper_q <- quantile(pi_list[[k]], 0.99)
  
  extreme_ps_id <- which(
    pi_list[[k]] < lower_q |
      pi_list[[k]] > upper_q
  )
  
  ylims <- range(pi_list[[k]])
  
  boxplot(
    pi_list[[k]] ~ A[index == k],
    names = c("A = 0", "A = 1"),
    main = paste0("Group ", k),
    xlab = "Treatment",
    ylab = "Prop Scores",
    outline = FALSE,
    ylim = ylims,
    cex.lab = 1.5,
    cex.axis = 1.6,
    cex.main = 1.8
  )
  
  stripchart(
    pi_list[[k]][extreme_ps_id] ~ A[index == k][extreme_ps_id],
    vertical = TRUE,
    method = "jitter",
    jitter = 0.15,
    pch = 16,
    col = "red",
    add = TRUE
  )
}

title(
  main = "Propensity Scores by Treatment",
  outer = TRUE,
  cex.main = 1.5
)

#IPWs
par(mfrow = c(2, 2), oma = c(0, 0, 3, 0))

for (k in 1:n){
  w_ipw <- ifelse(A[index == k] == 1,
                  1 / pi_list[[k]],
                  1 / (1 -pi_list[[k]]))
  threshold_w <- quantile(w_ipw, 0.95)
  extreme_w_id <- which(w_ipw > threshold_w)
  
  plot(A[index == k][extreme_w_id],
       w_ipw[extreme_w_id],
       main = paste0("Group ", k),
       pch = 16,
       col = "red",
       xlab = "Treatment",
       ylab = "IPW",
       xlim = c(-0.1, 1.1),
       cex.lab = 1.5, 
       cex.axis = 1.8,  
       cex.main = 1.6)
}
title(
  main = "5 % Most Extreme IPW",
  outer = TRUE,
  cex.main = 1.5
)

#check the EIFs
xlims <- range(unlist(psi_list))

par(mfrow = c(2, 2))

for (k in 1:n) {
  hist(
    psi_list[[k]],
    col = "lightblue",
    main = paste("Histogram of EIFs - Group", k),
    xlab = "EIF",
    ylab = "Frequency",
    xlim = xlims
  )
}


#CI's for the ATE of different groups
df3 <- data.frame(
  id = 1:n,
  mean = mean_preds,
  lower = mean_preds - 1.96*mean_sigmas,
  upper = mean_preds + 1.96*mean_sigmas
)

ggplot(df3, aes(x = mean, y = factor(id))) +
  geom_point(size = 3) +
  geom_errorbar(
    aes(xmin = lower, xmax = upper),
    width = 0.2,
    orientation = "y"
  ) +
  geom_vline(xintercept = 0, linetype = "dashed") +
  theme_minimal() +
  labs(
    x = "ATE - All groups",
    y = "Group"
  )



################################################################################################################################################################################################
#Question 3
################################################################################################################################################################################################

set.seed(100)
n <- nrow(pension)

n_folds <- 5
fold_id <- sample(rep(1:n_folds, length.out = n))
folds   <- split(seq_len(n), fold_id)

Q1 <- numeric(n)
Q0 <- numeric(n)
pi_hat <- numeric(n)
y_hat <- numeric(n)
cate <- numeric(n)

for (k in 1:n_folds) {
  
  test_fold  <- folds[[k]]
  train_fold <- setdiff(seq_len(n), test_fold)
  
  SL.library <- c("SL.gam", "SL.earth", "SL.ranger")
  
  sl_Q <- SuperLearner(
    Y          = Y[train_fold],
    X          = data.frame(A = A[train_fold], X[train_fold, ]),
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS"
  )
  
  sl_pi <- SuperLearner(
    Y          = A[train_fold],
    X          = X[train_fold, ],
    SL.library = SL.library,
    family     = binomial(),
    method     = "method.NNLS"
  )
  
  Q1[test_fold] <- predict(sl_Q, newdata = data.frame(A = 1, X[test_fold, ]))$pred
  Q0[test_fold] <- predict(sl_Q, newdata = data.frame(A = 0, X[test_fold, ]))$pred
  pi_hat[test_fold] <- predict(sl_pi, newdata = X[test_fold, ])$pred
  
  y_hat[test_fold] <- predict(sl_Q, newdata = data.frame(A = as.matrix(A[test_fold]), X[test_fold, ]))$pred

  cf <- causal_forest(X = X[train_fold, ],
                         Y = Y[train_fold],
                         W = A[train_fold],
                        num.trees = 10000
                      )
  
  cate[test_fold] <- predict(cf, newdata = X[test_fold, ])$pred
}

aug_1    <-  A      * (Y - Q1) / pi_hat
aug_0    <- (1 - A) * (Y - Q0) / (1 - pi_hat)
psi_i    <- (Q1 - Q0) + aug_1 - aug_0
ate_aipw <- mean(psi_i)

var_est <- (cate - ate_aipw)^2 + 2 * (cate - ate_aipw) * (A/pi_hat - (1-A)/(1-pi_hat)) * (Y - y_hat)
mean(var_est)

var_se  <- sd(var_est) / sqrt(n)
var_ci  <- mean(var_est) + c(-1, 1) * 1.96 * var_se

var_se
var_ci

eif <- var_est - mean(var_est)
mean(eif)

hist(eif,
     breaks = 100, 
     main = paste("Distribution efficient influence function"), 
     xlab = "Efficient influence function", 
     col = "navy")

df <- data.frame(
  var = mean(var_est),
  var_ci_lower = var_ci[1],
  var_ci_upper = var_ci[2]
)

ggplot(df, aes(x = var, y = 0)) +
  geom_point() +
  geom_errorbarh(aes(xmin = var_ci_lower, xmax = var_ci_upper), height = 0.2) +
  geom_vline(xintercept = 0, linetype = "dashed") +
  labs(x = "Variance", y = "Observation") +
  theme_minimal()

lower_q <- quantile(pi_hat, 0.01)
upper_q <- quantile(pi_hat, 0.99)
extreme_pi_id <- which(pi_hat < lower_q | pi_hat > upper_q)

boxplot(pi_hat ~ A,
        names = c("Control (A=0)", "Treated (A=1)"),
        ylab = "Propensity score",
        main = paste0("Propensity Scores"),
        outline = FALSE,
        cex.lab = 1.5, 
        cex.axis = 1.6,  
        cex.main = 1.8,)

stripchart(pi_hat[extreme_pi_id] ~ A[extreme_pi_id],
           vertical = TRUE,
           method = "jitter",
           jitter = 0.15,
           pch = 16,
           col = "red",
           add = TRUE)


#################################################################################################################################################################################################
#Question 4: The average treatment effect conditional on income
#################################################################################################################################################################################################

#Splitting of data into test vs train  set

#Trimmed data based on income (remove outliers for income)
#####
upper_bound_data <- quantile(Data_fr$inc, 0.985)
upper_bound_data
Data_fr_trimmed <- Data_fr[Data_fr$inc <= upper_bound_data, ]


Y <- Data_fr_trimmed$net_tfa
A <- Data_fr_trimmed$e401
X <- Data_fr_trimmed[c("age","inc","fsize","educ","marr","twoearn","db","pira","hown")]

n <- nrow(Data_fr_trimmed)
#####

n
train_id <- sample(1:n, size = floor(2/3 * n))
test_id  <- setdiff(1:n, train_id)


# Train_data, will be used to calculate propensity scores, mean outcomes and are used to obtain the pseudooutcomes
Y_train <- Y[train_id]
A_train <- A[train_id]
X_train <- X[train_id, ]

# Test_data, will be used to estimate the CATE
Y_test <- Y[test_id]
A_test <- A[test_id]
X_test <- X[test_id, ]

#Train data will again be splitted by cross fitting
n_train <- nrow(X_train)

n_folds_train <- 5
fold_id <- sample(rep(1:n_folds_train, length.out = n_train))
folds   <- split(seq_len(n_train), fold_id)


##############################
#Option 1: Using DR -learner
##############################

Q1_train <- numeric(n_train)
Q0_train <- numeric(n_train)

SL.library <- c("SL.glm", "SL.ranger", "SL.gam", "SL.earth", "SL.glmnet")

for (k in 1:n_folds_train) {
  
  test_fold  <- folds[[k]]
  train_fold <- setdiff(seq_len(n_train), test_fold)
  
  # Subset treated and control in TRAIN FOLD ONLY
  treated_id  <- train_fold[A_train[train_fold] == 1]
  control_id  <- train_fold[A_train[train_fold] == 0]
  
  sl_Q1 <- SuperLearner(
    Y          = Y_train[treated_id],
    X          =  X_train[treated_id, ],
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS"
  )
  
  sl_Q0 <- SuperLearner(
    Y          = Y_train[control_id],
    X          =  X_train[control_id, ],
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS"
  )
  
  Q1_train[test_fold] <- predict(sl_Q1, newdata = X_train[test_fold, ])$pred
  Q0_train[test_fold] <- predict(sl_Q0, newdata = X_train[test_fold, ])$pred
}

ps_hat_train <- numeric(n_train)


for (k in 1:n_folds_train) {
  
  test_fold  <- folds[[k]]
  train_fold <- setdiff(seq_len(n_train), test_fold)
  
  sl_ps <- SuperLearner(
    Y          = A_train[train_fold],
    X          = X_train[train_fold, ],
    SL.library = SL.library,
    family     = binomial(),
    method     = "method.NNLS"
  )
  
  ps_hat_train[test_fold] <- predict(sl_ps, newdata = X_train[test_fold, ])$pred
}

lower_q <- quantile(ps_hat_train, 0.01)
upper_q <- quantile(ps_hat_train, 0.99)
extreme_ps_id <- which(ps_hat_train < lower_q | ps_hat_train > upper_q)

boxplot(ps_hat_train ~ A_train,
        names = c("Control (A=0)", "Treated (A=1)"),
        ylab = "Propensity score",
        main = paste0("Propensity Scores for Training Data"),
        outline = FALSE,
        cex.lab = 1.5, 
        cex.axis = 1.6,  
        cex.main = 1.8,)

stripchart(ps_hat_train[extreme_ps_id] ~ A_train[extreme_ps_id],
           vertical = TRUE,
           method = "jitter",
           jitter = 0.15,
           pch = 16,
           col = "red",
           add = TRUE)

w_ipw <- ifelse(A_train == 1,
                1 / ps_hat_train,
                1 / (1 - ps_hat_train))
threshold_w <- quantile(w_ipw, 0.95)
extreme_w_id <- which(w_ipw > threshold_w)

plot(A_train[extreme_w_id],
     w_ipw[extreme_w_id],
     pch = 16,
     col = "red",
     xlab = "Treatment (A)",
     ylab = "IPW",
     xlim = c(-0.1, 1.1),
     cex.lab = 1.5, 
     cex.axis = 1.8,  
     cex.main = 1.6,
     main = "5 % Most Extreme IPW in Training Data")


aug_1_train    <-  A_train    * (Y_train - Q1_train) / ps_hat_train
aug_0_train    <- (1 - A_train) * (Y_train - Q0_train) / (1 - ps_hat_train)
pseudo_DR_lrnr_train    <- (Q1_train - Q0_train) + aug_1_train - aug_0_train

plot(X_train$inc, pseudo_DR_lrnr_train,
     pch = 16,
     col = rgb(0, 0, 0, 0.3),
     xlab = "Income",
     ylab = "Pseudo outcomes (DR-learner)",
     ylim= c(-50000, 50000),
     main = "Pseudo outcomes for training data vs Income (DR)")

boxplot(pseudo_DR_lrnr_train ~ A_train,
        names = c("Control (A=0)", "Treated (A=1)"),
        ylab = "Pseudo outcomes",
        main = "Pseudo outcomes for training data (DR)",
        outline = TRUE)

#We include ranger into the superlearner
SL.library <- c("SL.glm", "SL.gam", "SL.earth", "SL.ranger")
model.pseudooutcome.DR.incl.ranger <- SuperLearner(
  Y = pseudo_DR_lrnr_train,
  X = data.frame(inc = X_train$inc),
  SL.library = SL.library,
  family     = gaussian(),
  method     = "method.NNLS"
)
model.pseudooutcome.DR.incl.ranger
CATE_DR_test_with_ranger <- predict(model.pseudooutcome.DR.incl.ranger, newdata = data.frame(inc = X_test$inc), onlySL = TRUE)$pred

#We do not include ranger into the superlearner:
SL.library <- c("SL.glm", "SL.gam", "SL.earth")
model.pseudooutcome.DR.no.ranger <- SuperLearner(
  Y = pseudo_DR_lrnr_train,
  X = data.frame(inc = X_train$inc),
  SL.library = SL.library,
  family     = gaussian(),
  method     = "method.NNLS"
)
model.pseudooutcome.DR.no.ranger
CATE_DR_test_no_ranger <- predict(model.pseudooutcome.DR.no.ranger, newdata = data.frame(inc = X_test$inc), onlySL = TRUE)$pred


##############################
#Option 2: Using R -learner
##############################

Qa_train <- numeric(n_train)

SL.library <- c("SL.glm", "SL.ranger", "SL.gam", "SL.earth", "SL.glmnet")

for (k in 1:n_folds_train) {
  
  test_fold  <- folds[[k]]
  train_fold <- setdiff(seq_len(n_train), test_fold)
  
  sl_Qa <- SuperLearner(
    Y          = Y_train[train_fold],
    X          =  X_train[train_fold, ],
    SL.library = SL.library,
    family     = gaussian(),
    method     = "method.NNLS"
  )
  Qa_train[test_fold] <- predict(sl_Qa, newdata = X_train[test_fold, ])$pred
} 

pseudo_R_lrnr_train <- (Y_train - Qa_train) / (A_train - ps_hat_train)

plot(X_train$inc, pseudo_R_lrnr_train,
     pch = 16,
     col = rgb(0, 0, 0, 0.3),
     xlab = "Income",
     ylab = "CATE (DR-learner)",
     ylim = c(-200000, 200000),
     main = "Pseudo outcomes from training vs Income (DR)")

# Regress the pseudo-outcomes in the combined training data set using weighted SuperLearner

weigths_R_lrnr_train <- (A_train - ps_hat_train)^2

#We include ranger in the superlearner
SL.library <- c("SL.glm", "SL.gam", "SL.earth", "SL.ranger")
model.pseudooutcome.R.inc.ranger <- SuperLearner(
  Y = pseudo_R_lrnr_train, 
  X = data.frame(inc = X_train$inc), 
  SL.library = SL.library, 
  obsWeights = weigths_R_lrnr_train, 
  family = gaussian)
CATE_R_test_with_ranger <- predict(model.pseudooutcome.R.inc.ranger, newdata = data.frame(inc = X_test$inc), onlySL = TRUE)$pred
model.pseudooutcome.R.inc.ranger

#We do not include ranger in the superlearner
SL.library <- c("SL.glm", "SL.gam", "SL.earth")
model.pseudooutcome.R.no.ranger <- SuperLearner(
  Y = pseudo_R_lrnr_train, 
  X = data.frame(inc = X_train$inc), 
  SL.library = SL.library, 
  obsWeights = weigths_R_lrnr_train, 
  family = gaussian)
model.pseudooutcome.R.no.ranger
CATE_R_test_no_ranger <- predict(model.pseudooutcome.R.no.ranger, newdata = data.frame(inc = X_test$inc), onlySL = TRUE)$pred


#######
#Results
#######

##Comparison of two methods (including ranger):
plot(X_test$inc, CATE_DR_test_with_ranger,
     pch = 16,
     col = adjustcolor("gold", alpha.f = 0.5),
     xlab = "Income",
     ylab = "CATE",
     main = "Predicted CATE for test dataset")

points(X_test$inc, CATE_R_test_with_ranger,
       pch = 16,
       col = adjustcolor("darkseagreen", alpha.f = 0.5))

legend("topright",
       legend = c("DR-learner", "R-learner"),
       col = c("gold", "darkseagreen"),
       pch = 16)

##Comparison of two methods (without ranger):
plot(X_test$inc, CATE_DR_test_no_ranger,
     pch = 16,
     col = adjustcolor("gold", alpha.f = 0.5),
     xlab = "Income",
     ylab = "CATE",
     main = "Estimated CATE (Predictions for Samples in Testdata)",
     cex.lab = 1.6, 
     cex.axis = 1.6,  
     cex.main = 1.8)

points(X_test$inc, CATE_R_test_no_ranger,
       pch = 16,
       col = adjustcolor("darkseagreen", alpha.f = 0.5))

legend("topright",
       legend = c("DR-learner", "R-learner"),
       col = c("gold", "darkseagreen"),
       pch = 16,
       cex = 1.6)


